/*********************************************************************
*                                                                    *
* Copyright (c)                                                      *
* ZJU-DBL, Zhejiang University, Hangzhou, China                      *
*                                                                    *
* All Rights Reserved.                                               *
*                                                                    *
* Permission to use, copy, and distribute this software and its      *
* documentation for NON-COMMERCIAL purposes and without fee is       *
* hereby granted provided  that this copyright notice appears in     *
* all copies.                                                        *
*                                                                    *
* THE AUTHORS MAKE NO REPRESENTATIONS OR WARRANTIES ABOUT THE        *
* SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING  *
* BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,      *
* FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR  *
* SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A      *
* RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS    *
* DERIVATIVES.                                                       *
*                                                                    *
*********************************************************************/

#include <iostream>
#include <fstream>
#include <math.h>
#include <time.h>
#include <vector>
#include <direct.h>
using namespace std;

#include "./blockfile/blk_file.h"
#include "./blockfile/cache.h"
#include "./gadget/gadget.h"
#include "./heap/binheap.h"
#include "./heap/heap.h"
#include "./rand/rand.h"
#include "./object.h"
#include "./RAF.h"
#include "./pb-tree.h"
#include <string>
#include"lsb_vector\m-entry.h"
double compdists = 0;
double IOread = 0;
double IOwrite = 0;
double cc = 0;
int MAXINT, MAXNUM, MAXLEVEL;
double EPS, MAXDIST;
int dim, num_obj, func;
int blocksize;

// Note that the id of data in the file should begin with 0
Object ** readobjects(char* filename, int num_obj, int dim)
{
	FILE *fp;

	int record_count = 0;
	Object ** objset = new Object*[num_obj];
	for (int i = 0;i<num_obj;i++)
	{
		objset[i] = new Object();
	}

	if ((fp = fopen(filename, "r")) == NULL)
	{
		for (int i = 0;i<num_obj;i++)
			delete objset[i];
		error("Could not open the data file", TRUE);
	}
	else
	{
		fscanf(fp, "%d %d %d", &dim, &num_obj, &func);
		while (record_count<num_obj)
		{
			float d;
			objset[record_count]->id = record_count;
			objset[record_count]->size = dim;
			objset[record_count]->data = new float[objset[record_count]->size];
			for (int i = 0; i < objset[record_count]->size; i++)
			{
				fscanf(fp, "%f", &d);
				objset[record_count]->data[i] = d/yiwan;
			}
			fscanf(fp, "\n");
			record_count++;
		}
	}

	return objset;
}

Object * readobjects2(char* filename)
{
	FILE *fp;
	int record_count = 0;

	if ((fp = fopen(filename, "r")) == NULL)
	{
		error("Could not open the data file", TRUE);
		return NULL;
	}
	else
	{
		fscanf(fp, "%d %d %d", &dim, &num_obj, &func);

		Object * objset = new Object[num_obj];
		while (record_count < num_obj)
		{
			float d;
			objset[record_count].id = record_count;
			objset[record_count].size = dim;
			objset[record_count].data = new float[dim];
			for (int i = 0; i < dim; i++)
			{
				fscanf(fp, "%f", &d);
				objset[record_count].data[i] = d/yiwan;
			}
			fscanf(fp, "\n");
			record_count++;
		}
		return objset;
	}

}

clock_t bulidIndex(char* index_name, char * filename,char *pname, int n_p)
{
	/*******
	index_name -- the path of the index to be stored
	filename -- the path of the dataset
	pname -- the path of pivots
	n_p -- the number of pivots
	*******/

	//pivot selection    
	PB_Tree * pb = new PB_Tree();

	//parameter settings	
	pb->num_cand = 40; // the number of candidates for selecting pivots
	pb->num_piv = n_p;

	int keysize;
	Object * os = readobjects2(filename); // the function needed to be rewirte to read differnt formats of the dataset
	pb->readptable(pname);


	IOread = IOwrite = compdists = 0;
	clock_t begin;
	char ptablefile[] = "ptable.txt";
	ofstream out1(ptablefile);
	out1 << pb->num_piv << endl;
	if(pb->num_piv<=MAXLEVEL)
		MAXLEVEL = pb->num_piv - 1;
	for (int i = 0; i<pb->num_piv; i++)
	{
		out1 << pb->ptable[i].id << " " << pb->ptable[i].size << " ";
		for (int j = 0; j<pb->ptable[i].size; j++)
			out1 << pb->ptable[i].data[j] << " ";
		out1 << endl;
	}
	out1.close();
	compdists = 0;
	begin = clock();
	pb->bulkload(os, num_obj);

	cout << "builing B+-tree" << endl;
	pb->bplus = new B_Tree();
	pb->bplus->init(index_name, blocksize, NULL, pb->num_piv);
	char bl[] = "bulkload.txt";
	pb->bplus->bulkload("bulkload.txt", os,num_obj);
	delete[] os;

	////build RAF

	cout << "building RAF" << endl;
	pb->bplus->load_root();
	B_Node * node = pb->bplus->root_ptr;
	B_Node * temp;

	while (node->level != 0)
	{
		node = node->entries[0]->get_son();
	}
	int * obj_order = new int[num_obj];
	int k = 0;
	for (int i = 0; i<node->num_entries; i++)
	{
		obj_order[k] = node->entries[i]->son;
		k++;
	}
	temp = node->get_right_sibling();
	//delete node;
	while (temp != NULL)
	{
		node = temp;
		for (int i = 0; i<node->num_entries; i++)
		{
			obj_order[k] = node->entries[i]->son;
			k++;
		}
		temp = node->get_right_sibling();
		delete node;
	}

	pb->draf = new RAF();
	pb->draf->num_obj = num_obj;
	pb->draf->init(index_name, blocksize, NULL);

	Object ** objS = readobjects(filename, num_obj, dim);
	int * result = pb->draf->buid_from_array(objS, obj_order);

	//delete object sets
	for (int i = 0; i<num_obj; i++)
		delete objS[i];
	delete[] obj_order;

	node = pb->bplus->root_ptr;


	while (node->level != 0)
	{
		node = node->entries[0]->get_son();
	}

	k = 0;
	for (int i = 0; i<node->num_entries; i++)
	{
		node->entries[i]->ptr = result[k];
		k++;
	}
	char * buffer = new char[blocksize];
	node->write_to_buffer(buffer);

	pb->bplus->file->write_block(buffer, node->block);
	delete buffer;

	temp = node->get_right_sibling();
	//delete node;
	while (temp != NULL)
	{
		buffer = new char[blocksize];
		node = temp;
		for (int i = 0; i<node->num_entries; i++)
		{
			node->entries[i]->ptr = result[k];
			k++;
		}
		node->write_to_buffer(buffer);

		pb->bplus->file->write_block(buffer, node->block);

		delete buffer;
		temp = node->get_right_sibling();
		delete node;
	}
	delete[] result;

	pb->bplus->close();
	return begin;
}

#define ARRAYLENGTH 100



void main(int argc, char** argv)
{
	clock_t begin, buildEnd, queryEnd;
	double buildComp, queryComp;
	struct stat sdata1;
	struct stat sdata2;
	struct stat sdata3;
	

	int buffer_size = 32;
	
	char * datafile = argv[1]; // the path of input data file
	char * pname = argv[2]; // the path of input pivots
	char * indexfile = argv[3]; // the path to store the built index
	
	FILE * f = fopen(argv[4], "w"); // the path to store the building and query cost
	MAXDIST = atof(argv[5]);  // the maximum distance for the input dataset

	EPS = MAXDIST / 1000;
	MAXINT = MAXDIST / EPS;
	MAXNUM = 1600; //  the number of objects in one cluster (can be any value set by the user)


	double radius[7];
	int kvalues[] = { 1, 5, 10, 20, 50, 100 };

	if (string(datafile).find("LA") != -1) {
		double r[] = { 473, 692, 989, 1409, 1875, 2314, 3096 };
		memcpy(radius, r, sizeof(r));
	}
	else if (string(datafile).find("integer") != -1) {
		double r[] = { 2321,2733, 3229,3843, 4614, 5613, 7090 };
		memcpy(radius, r, sizeof(r));
	}
	else if (string(datafile).find("sf") != -1) {
		double r[] = { 100, 200, 300, 400, 500, 600, 700 };
		memcpy(radius, r, sizeof(r));
	}
	else if (string(datafile).find("mpeg_1M") != -1) {
		double r[] = { 3838, 4092, 4399, 4773, 5241, 5904, 7104};
		memcpy(radius, r, sizeof(r));
	}

	int pvnb = atoi(argv[6]);	// the number of pivots
	blocksize = atoi(argv[7]); // the page size
	char* querydata = argv[8]; // the path of input query data

	//***********************************************build the index****************************************
	
	int pn = pvnb;
	MAXLEVEL = pn - 1; // MAXLEVEL is the height of dynamic cluster tree
	if (pn > 5)
		MAXLEVEL = 5;

	fprintf(f, "pivotnum: %d\n", pn);
	compdists = 0;
	IOread = IOwrite = 0;
	begin = bulidIndex(indexfile, datafile,pname, pn);

	char nodefile[] = "node.b";

	//compute the blocksize
	M_Entry te;
	te.num_piv = pn;
	int blocklength = sizeof(int) * 4 + pn*te.get_size();

	PB_Tree * pb = new PB_Tree();
	pb->bf = new BlockFile(nodefile, blocklength);

	Cache* c = new Cache(buffer_size, blocksize);
	Cache* b = new Cache(buffer_size, blocksize);
	pb->c = c;
	pb->num_piv = pn;
	pb->bplus = new B_Tree();
	pb->bplus->init_restore(indexfile, b);
	pb->readptable(pname);

	buildEnd = clock() - begin;
	buildComp = compdists;
	fprintf(f, "building...\n");
	fprintf(f, "finished... %f build time\n", (double)buildEnd / CLOCKS_PER_SEC);
	fprintf(f, "finished... %f distances computed\n", buildComp);
	fprintf(f, "finished... %f IO reads\n", IOread);
	fprintf(f, "finished... %f IO IOwrites\n",IOwrite);
	char * bfile = new char[strlen(indexfile) + 2];
	strcpy(bfile, indexfile);
	strcat(bfile, ".b");
	char * raffile = new char[strlen(indexfile) + 4];
	strcpy(raffile, indexfile);
	strcat(raffile, ".raf");
	stat(bfile, &sdata1);
	stat(raffile, &sdata2);
	stat(nodefile, &sdata3);
	fprintf(f, "saved... %lli bytes\n", (long long)(sdata1.st_size + sdata2.st_size + sdata3.st_size));
	fflush(f);

	fprintf(f, "\nquerying...\n");
	pb->draf = new RAF();
	pb->draf->init_restore(indexfile, c);

	//******************************similarity query***********************************************

	Object * q = new Object();
	ifstream in;
	int qcount = 100; // the number of quereis
		
	double io = 0;
	double dists = 0;
	double pf = 0;
	q->size = dim;
	q->data = new float[q->size];
	double rad;
	cout << "start knnSearching......" << endl;
	for (int k = 0; k < 6; k++) {
		in.open(querydata);
		begin = clock();
		dists = 0;
		pf = 0;
		rad = 0;

		for (int j = 0; j < qcount; j++)
		{
			IOread = 0;				
			c->clear();
			b->clear();
			compdists = 0;

			float temp;
			for (int i = 0; i < q->size; i++)
			{
				in >> temp;
				q->data[i] = temp / yiwan;
			}
							
			rad += pb->knn(q, kvalues[k]);

			pf += b->page_faults + c->page_faults;
			dists += compdists;
		}
		queryEnd = clock() - begin;
		queryComp = dists;
		fprintf(f, "\nkNN Query k: %d\n", kvalues[k]);
		fprintf(f, "finished... %f query time\n", (double)queryEnd / CLOCKS_PER_SEC / qcount);
		fprintf(f, "finished... %f distances computed\n", queryComp / qcount);
		fprintf(f, "finished... %f IO times\n", pf / qcount);
		fprintf(f, "finished... %f radius\n", rad / qcount);

		in.close();
		fflush(f);

		cout << "start rangeSearching......" << endl;
		for (int k = 0; k < 7; k++) {
			in.open(querydata);
			begin = clock();
			dists = 0;
			pf = 0;
			rad = 0;

			for (int j = 0; j < qcount; j++)
			{
				IOread = 0;
				c->clear();
				b->clear();
				compdists = 0;

				float temp;
				for (int i = 0; i < q->size; i++)
				{
					in >> temp;
					q->data[i] = temp / yiwan;
				}
				
				rad += pb->rangequery(q, radius[k] / yiwan);
				pf += b->page_faults + c->page_faults;
				dists += compdists;
			}
			queryEnd = clock() - begin;
			queryComp = dists;
			fprintf(f, "\nRange Query r: %f\n", radius[k]);
			fprintf(f, "finished... %f query time\n", (double)queryEnd / CLOCKS_PER_SEC / qcount);
			fprintf(f, "finished... %f distances computed\n", queryComp / qcount);
			fprintf(f, "finished... %f IO times\n", pf / qcount);
			fprintf(f, "finished... %f objs\n", rad / qcount);
			in.close();
			fflush(f);
		}

		q = NULL;
		pb = NULL;
		fprintf(f, "\n");
	}
}


