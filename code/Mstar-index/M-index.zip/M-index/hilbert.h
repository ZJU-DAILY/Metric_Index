#ifndef hilbert_h
#define hilbert_h


#define WORDBITS 32
#define NUMBITS 32



#endif