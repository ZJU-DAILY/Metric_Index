#include "LC.h"
#include <chrono>
#include <iostream>
#include <fstream>
#include <iterator>
using namespace std;
using namespace chrono;

int main(int argc,char **argv)
{
	time_point<steady_clock> start_time, end_time;
	milliseconds sum_time;

	char *dataPath = argv[1];
	char *queryPath = argv[2];
	char *costFile = argv[3];
	int blockSize = atoi(argv[4]);
	ofstream fout(costFile, ios::out);

	//different LC_xxx_t for different dataset
	cout << "start building LC......" << endl;
	LC_dbl_t lc_db;
	start_time = steady_clock::now();
	lc_db.build(string(dataPath), blockSize); //build LC
	end_time = steady_clock::now();
	lc_db.restore(string(dataPath));	
	sum_time = duration_cast<milliseconds>(end_time - start_time);
	fout << "build time:" << (double)sum_time.count() / 1000 << endl;
	fout << "compdists:" << lc_db.dist_cnt << endl;
	fout << "IOreads:" << lc_db.read_cnt << endl;
	fout << "IOwrites:" << lc_db.write_cnt << endl;	
	string query_path(queryPath);
	double data[2];

	//LC_int_t lc_db;
	//start_time = steady_clock::now();
	////lc_db.build("../data/integer", 40960); //1489 * 1365
	//lc_db.build(string(dataPath), blockSize);
	//end_time = steady_clock::now();
	//sum_time = duration_cast<milliseconds>(end_time - start_time);
	//fout << "build time:" << (double)sum_time.count() / 1000 << endl;
	//fout << "compdists:" << lc_db.dist_cnt << endl;
	//fout << "IOreads:" << lc_db.read_cnt << endl;
	//fout << "IOwrites:" << lc_db.write_cnt << endl;
	////lc_db.restore("../data/integer");
	//lc_db.restore(string(dataPath));	
	////string query_path("../data/integer_query.txt");
	//string query_path(queryPath);
	//int data[20];

	//LC_int_t lc_db;
	//start_time = steady_clock::now();
	////lc_db.build("../dataset/mpeg", 40960); //1846 * 1833
	//lc_db.build(string(dataPath), blockSize);
	//end_time = steady_clock::now();
	//sum_time = duration_cast<milliseconds>(end_time - start_time);
	//fout << "build time:" << (double)sum_time.count() / 1000 << endl;
	//fout << "compdists:" << lc_db.dist_cnt << endl;
	//fout << "IOreads:" << lc_db.read_cnt << endl;
	//fout << "IOwrites:" << lc_db.write_cnt << endl;
	////lc_db.restore("../dataset/mpeg");
	//lc_db.restore(string(dataPath));
	////string query_path("../dataset/mpeg_query.txt");
	//string query_path(queryPath);
	//int data[282];
	

	//LC_str_t lc_db;
	//start_time = steady_clock::now();
	////lc_db.build("../data/moby", 4096); //1170 * 1024
	//lc_db.build(string(dataPath), blockSize);  //build LC
	//end_time = steady_clock::now();
	//sum_time = duration_cast<milliseconds>(end_time - start_time);
	//fout << "build time:"  << sum_time.count() / 1000 << endl;
	//fout << "compdists:" << lc_db.dist_cnt << endl;
	//fout << "IOreads:" << lc_db.read_cnt << endl;
	//fout << "IOwrites:" << lc_db.write_cnt << endl;	
	//lc_db.restore(string(dataPath));	
	//string query_path(queryPath);
	//char data[48];

	float radius[7];
	int kvalues[] = { 1, 5, 10, 20, 50, 100 };
	if (string(query_path).find("LA") != -1) {
		float r[] = { 473, 692, 989, 1409, 1875, 2314, 3096 };
		memcpy(radius, r, sizeof(r));
	}
	else if (string(query_path).find("integer") != -1) {
		float r[] = { 2321,2733, 3229,3843, 4614, 5613, 7090 };
		memcpy(radius, r, sizeof(r));
	}
	else if (string(query_path).find("sf") != -1) {
		float r[] = { 100, 200, 300, 400, 500, 600, 700 };
		memcpy(radius, r, sizeof(r));
	}
	else if (string(query_path).find("mpeg") != -1) {
		float r[] = { 3838, 4092, 4399, 4773, 5241, 5904, 7104 };
		memcpy(radius, r, sizeof(r));
		//memcpy(radius, r, 7*sizeof(float));
	}
	else if (string(query_path).find("moby") != -1) {
		float r[] = { 2, 3, 4, 5, 6, 8, 10 };
		memcpy(radius, r, sizeof(r));
	}

	FILE* fquery = fopen(query_path.c_str(), "r");
	int qcount = 100;	
	fout << "querying..." << endl;

	cout << "start knnSearching......" << endl;
	int sum_dist_call_cnt = 0;
	for (int k : kvalues) {
		lc_db.dist_cnt = 0;
		lc_db.index_fp.read_cnt = 0;
		lc_db.node_fp.read_cnt = 0;
		start_time = steady_clock::now();

		double ave_r = 0.0;
		int cnt = 0;

		fseek(fquery, 0, SEEK_SET);
		while (cnt++ < qcount)
		{
			lc_db.read_data(fquery, data);
			ave_r += lc_db.knn(data, k); //knnSearch
		}
		end_time = steady_clock::now();
		sum_time = duration_cast<milliseconds>(end_time - start_time);
	
		fout << "\nkNN Query k: " << k << endl;		
		fout << "query time = " << (double)sum_time.count()/1000/qcount << endl;
		fout << "compdists = " << lc_db.dist_cnt/qcount << endl;
		fout << "IOread = " << (lc_db.index_fp.read_cnt + lc_db.node_fp.read_cnt)/qcount << endl;
		fout << "result radius: " << ave_r/qcount << endl;
	}

	cout << "start rangeSearching......" << endl;
	sum_dist_call_cnt = 0;
	for (double r : radius) {
		lc_db.dist_cnt = 0;
		lc_db.index_fp.read_cnt = 0;
		lc_db.node_fp.read_cnt = 0;
		start_time = steady_clock::now();

		size_t result_size = 0;
		int cnt = 0;

		fseek(fquery, 0, SEEK_SET);
		while (cnt++ < qcount)
		{
			lc_db.read_data(fquery, data);
			result_size += lc_db.range(data, r); //rangeSearch
		}
		end_time = steady_clock::now();
		sum_time = duration_cast<milliseconds>(end_time - start_time);		
		fout << "\nRange Query r: " << r << endl;		
		fout << "query time = " << (double)sum_time.count()/1000/qcount << endl;
		fout << "compdists = " << lc_db.dist_cnt/qcount << endl;
		fout << "IOread = " << (lc_db.index_fp.read_cnt + lc_db.node_fp.read_cnt)/qcount << endl;
		fout << "Number of results: " << result_size/qcount << endl;
	}
	fout.flush();
	fout.close();

	return 0;
}