#pragma once
#include "dist.h"
#include "file.h"
#include <set>
using namespace std;

struct LC_t
{
	struct center_t
	{
		double dist;
		int64_t id;
		char data[1];
	};

	char header_start = 1;
	int dim = 0, func = 0, n = 0;
	int page_size = 0, obj_size = 0, center_size = 0;
	int page_obj_cnt = 0, node_cnt = 0;
	char header_end = 1;

	file_t index_fp, node_fp;

	center_t* obj = nullptr, * center = nullptr;

	double dist_cnt = 0;
	int read_cnt = 0, write_cnt = 0;
	double (*_dist)(void* a, void* b, int n) = nullptr;
	double dist(void* a, void* b);

	virtual void set_func() = 0;
	virtual void read_data_header(FILE* fp) = 0;
	virtual void read_data(FILE* fp, void* data) = 0;
	void prepare(FILE* data_file, file_t& write_fp);
	void write_header(string path);
	void find_center(file_t & read_fp, int node_left);
	void find_radius(file_t& read_fp, file_t& write_fp, int node_left, set<int64_t>& objs);
	void divide_objs(file_t& read_fp, file_t& write_fp, int node_left, set<int64_t>& objs);
	void build(string path, int page_size);

	void read_header(string path);
	void restore(string path);

	int range(void* query, double range);
	double knn(void* query, int k);
};

struct LC_int_t : public LC_t
{
	void set_func() override;
	void read_data_header(FILE* fp) override;
	void read_data(FILE* fp, void* data) override;
};

struct LC_dbl_t : public LC_t
{
	void set_func() override;
	void read_data_header(FILE* fp) override;
	void read_data(FILE* fp, void* data) override;
};

struct LC_str_t : public LC_t
{
	void set_func() override;
	void read_data_header(FILE* fp) override;
	void read_data(FILE* fp, void* data) override;
};