#include <cstdlib>
#include "file.h"

void file_t::init(const char* path, const char* mode, int page_size, int item_size)
{
	fp = fopen(path, mode);
	if (fp == nullptr) {
		auto e = errno;
		perror(path);
		exit(EXIT_FAILURE);
	}
	page = (char*)malloc(page_size);
	read_pos = page + page_size;
	write_pos = page;
	this->page_size = page_size;
	this->item_size = item_size;
	read_cnt = write_cnt = 0;
}

file_t::~file_t()
{
	close();
}

void file_t::seek(int n)
{
	if (write_pos > page) {
		++write_cnt;
		fwrite(page, page_size, 1, fp);
	}
	_fseeki64(fp, n * page_size, SEEK_SET);
	read_pos = page + page_size;
	write_pos = page;
}

void file_t::write(const void* item, size_t size)
{
	if (size == -1) {
		size = item_size;
	}
	memcpy(write_pos, item, size);
	write_pos += size;
	if (write_pos + size > page + page_size) {
		++write_cnt;
		fwrite(page, page_size, 1, fp);
		write_pos = page;
	}
}

void file_t::read(void* item, size_t size)
{
	if (size == -1) {
		size = item_size;
	}
	if (read_pos + size > page + page_size) {
		++read_cnt;
		fread(page, page_size, 1, fp);
		read_pos = page;
	}
	memcpy(item, read_pos, size);
	read_pos += size;
}

void file_t::close()
{
	if (fp == nullptr) {
		return;
	}
	if (write_pos > page) {
		++write_cnt;
		fwrite(page, page_size, 1, fp);
	}
	free(page);
	page = write_pos = read_pos = nullptr;
	fclose(fp);
}