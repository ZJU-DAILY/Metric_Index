#include "LC.h"
#include "file.h"
#include <queue>
#include <set>
#include <stdexcept>
#include <cstring>
#include <cassert>
using namespace std;

double LC_t::dist(void* a, void* b)
{
	++dist_cnt;
	return _dist(a, b, dim);
}

void LC_dbl_t::set_func()
{
	switch (func) {
	case 0:
		_dist = Linf<double>;
		break;
	case 1:
		_dist = L1<double>;
		break;
	case 2:
		_dist = L2<double>;
		break;
	case 5:
		_dist = L5<double>;
	}
}

void LC_int_t::set_func()
{
	switch (func) {
	case 0:
		_dist = Linf<int>;
		break;
	case 1:
		_dist = L1<int>;
		break;
	case 2:
		_dist = L2<int>;
		break;
	case 5:
		_dist = L5<int>;
	}
}

void LC_str_t::set_func()
{
	_dist = Lstr<char>;
}

void LC_dbl_t::read_data_header(FILE* fp)
{
	fscanf(fp, "%d %d %d", &dim, &n, &func);
	printf("dim = %d, n = %d, func = %d\n", dim, n, func);
	obj_size = sizeof(int64_t) + dim * sizeof(double);
}

void LC_int_t::read_data_header(FILE* fp)
{
	fscanf(fp, "%d %d %d", &dim, &n, &func);
	printf("dim = %d, n = %d, func = %d\n", dim, n, func);
	obj_size = sizeof(int64_t) + dim * sizeof(int);
}

void LC_str_t::read_data_header(FILE* fp)
{
	dim = 50;
	fscanf(fp, "%d", &n);
	printf("dim = %d, n = %d\n", dim, n);
	obj_size = sizeof(int64_t) + dim * sizeof(char);
}

void LC_dbl_t::read_data(FILE* fp, void* _data)
{
	double* data = (double*)_data;
	for (int j = 0; j < dim; ++j) {
		fscanf(fp, "%lf", data);
		++data;
	}
}

void LC_int_t::read_data(FILE* fp, void* _data)
{
	int* data = (int*)_data;
	for (int j = 0; j < dim; ++j) {
		fscanf(fp, "%d", data);
		++data;
	}
}

void LC_str_t::read_data(FILE* fp, void* _data)
{
	char* data = (char*)_data;
	fscanf(fp, "%s", data);
	assert(strlen(data) < dim);
}

void LC_t::prepare(FILE* data_fp, file_t& write_fp)
{
	obj->dist = 0.0;
	for (int i = 0; i < n; ++i) {
		obj->id = i;
		read_data(data_fp, obj->data);
		write_fp.write(obj);
	}
	write_fp.seek(0);
}

void LC_t::write_header(string path)
{
	FILE* header_fp = fopen((path + ".lc_header").c_str(), "wb+");
	fwrite(&header_start, &header_end - &header_start, 1, header_fp);
	fclose(header_fp);
}

void LC_t::find_center(file_t& read_fp, int obj_left)
{
	read_fp.read(center);
	for (int i = 1; i < obj_left; ++i) {
		read_fp.read(obj);
		//if (obj->dist < center->dist) {
		if (obj->dist > center->dist) {
			memcpy(center, obj, read_fp.item_size);
		}
	}
	read_fp.seek(0);
}

void LC_t::find_radius(file_t& read_fp, file_t& write_fp, int obj_left, set<int64_t>& objs)
{
	priority_queue<pair<double, int64_t>> q;
	for (int i = 0; i < obj_left; ++i) {
		read_fp.read(obj);
		if (obj->id == center->id) {
			continue;
		}
		double d = dist(obj->data, center->data);
		q.emplace(d, obj->id);
		if (q.size() > page_obj_cnt) {
			q.pop();
		}
		obj->dist += d;
		write_fp.write(obj);
	}
	
	if(q.size()!=0)center->dist = q.top().first;
	while (!q.empty()) {
		objs.insert(q.top().second);
		q.pop();
	}
	read_fp.seek(0);
	write_fp.seek(0);
}

void LC_t::divide_objs(file_t& read_fp, file_t& write_fp, int obj_left, set<int64_t>& objs)
{
	for (int i = 0; i < obj_left; ++i) {
		read_fp.read(obj);
		if (objs.find(obj->id) != objs.end()) {
			node_fp.write(&obj->id);
		}
		else {
			write_fp.write(obj);
		}
	}
	read_fp.seek(0);
	write_fp.seek(0);
}

void LC_t::build(string path, int page_size)
{
	this->page_size = page_size;
	FILE* data_fp = fopen((path + ".txt").c_str(), "rb");
	read_data_header(data_fp);
	page_obj_cnt = page_size / obj_size;
	node_cnt = (n + page_obj_cnt) / (1 + page_obj_cnt);
	center_size = sizeof(double) + obj_size;
	printf("obj_size = %d, page_obj_cnt = %d\n", obj_size, page_obj_cnt);
	printf("center_size = %d, node_cnt = %d\n", center_size, node_cnt);
	write_header(path);

	file_t tmp1_fp, tmp2_fp;
	tmp1_fp.init((path + ".tmp1").c_str(), "wb+", page_size, center_size);
	tmp2_fp.init((path + ".tmp2").c_str(), "wb+", page_size, center_size);
	index_fp.init((path + ".lc_index").c_str(), "wb+", page_size, center_size);
	node_fp.init((path + ".lc_node").c_str(), "wb+", page_size, obj_size);
	obj = (center_t*)malloc(center_size);
	center = (center_t*)malloc(center_size);

	set_func();
	prepare(data_fp, tmp1_fp);
	fclose(data_fp);
	int obj_left = n;
	printf("building......\n");
	for (int i = 0; i < node_cnt; ++i) {
		set<int64_t> objs;
		find_center(tmp1_fp, obj_left);
		find_radius(tmp1_fp, tmp2_fp, obj_left, objs);
		index_fp.write(center);
		--obj_left;
		//printf("%f\r", i * 1.0 / node_cnt);
		divide_objs(tmp2_fp, tmp1_fp, obj_left, objs);
		obj_left -= page_obj_cnt;
		//printf("%f\t",(float)i/node_cnt);
	}
	int read_sum = tmp1_fp.read_cnt + tmp2_fp.read_cnt;
	int write_sum = tmp1_fp.write_cnt + tmp2_fp.write_cnt;
	read_cnt = read_sum;
	write_cnt = write_sum;
	printf("\n%d reads, %d writes, %d distcmp.\n", read_sum, write_sum, dist_cnt);

	free(center);
	center = nullptr;
	free(obj);
	obj = nullptr;
	index_fp.close();
	node_fp.close();
}

void LC_t::read_header(string path)
{
	FILE* header_fp = fopen((path + ".lc_header").c_str(), "rb+");
	fread(&header_start, &header_end - &header_start, 1, header_fp);
	fclose(header_fp);
}

void LC_t::restore(string path)
{
	read_header(path);
	set_func();
	index_fp.init((path + ".lc_index").c_str(), "rb+", page_size, center_size);
	node_fp.init((path + ".lc_node").c_str(), "rb+", page_size, obj_size);
	obj = (center_t*)malloc(center_size);
	center = (center_t*)malloc(center_size);
}

int LC_t::range(void* query, double range)
{
	int res = 0;
	for (int i = 0; i < node_cnt; ++i) {
		index_fp.read(center);
		double d = dist(center->data, query);
		if (d > center->dist + range) {
			continue;
		}
		if (d <= range) {
			++res;
		}
		node_fp.seek(i);
		for (int j = 0; j < min(page_obj_cnt, n - i * (page_obj_cnt + 1) - 1); ++j) {
			node_fp.read(&obj->id);
			if (dist(obj->data, query) <= range) {
				++res;
			}
		}
	}
	index_fp.seek(0);
	return res;
}

double LC_t::knn(void* query, int k)
{
	double avg_r = 0.0;
	priority_queue<double> res;
	for (int i = 0; i < node_cnt; ++i) {
		index_fp.read(center);
		double d = dist(center->data, query);
		if (res.size() >= k && (d - center->dist) >= res.top()) {
			continue;
		}
		if (res.size() < k) {
			res.push(d);
			avg_r += d;
		}
		else if (d < res.top()) {
			res.push(d);
			avg_r -= res.top();
			avg_r += d;
			res.pop();
		}
		node_fp.seek(i);
		for (int j = 0; j < min(page_obj_cnt, n - i * (page_obj_cnt + 1) - 1); ++j) {
			node_fp.read(&obj->id);
			double distance = dist(obj->data, query);
			if (res.size() < k) {
				res.push(distance);
				avg_r += distance;
			}
			else if (distance < res.top()) {
				res.push(distance);
				avg_r -= res.top();
				avg_r += distance;
				res.pop();
			}
		}
	}
	avg_r = res.top();
	index_fp.seek(0);
	return avg_r;
}