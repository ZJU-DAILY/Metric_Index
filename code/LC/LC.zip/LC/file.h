#pragma once
#include <cstdio>
#include <cstring>
using namespace std;

struct file_t
{
	FILE* fp = nullptr;
	char* page = nullptr, * read_pos = nullptr, * write_pos = nullptr;
	size_t page_size = 0, item_size = 0;
	int write_cnt = 0, read_cnt = 0;

	file_t()
	{
	}
	~file_t();
	void init(const char* path, const char* mode, int page_size, int item_size);
	void close();
	void seek(int n);
	void write(const void* item, size_t size = -1);
	void read(void* item, size_t size = -1);
};
