Four parameters are needed when starting the program. 
The four parameters are as follows:
dataset filename, query filename, cost filename, pageSize
eg. ..\\dataset\\moby ..\\dataset\\moby_query.txt LC-moby-cost.txt 4096