#include <cmath>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;

template <typename T>
double L1(void* _a, void* _b, int n)
{
	T* a = (T*)_a, * b = (T*)_b;
	double dist = 0.0;
	for (int i = 0; i < n; i++) {
		dist += fabs(a[i] - b[i]);
	}
	return dist;
}

template <typename T>
double L2(void* _a, void* _b, int n)
{
	T* a = (T*)_a, * b = (T*)_b;
	double dist = 0.0;
	for (int i = 0; i < n; i++) {
		dist += pow(a[i] - b[i], 2);
	}
	return sqrt(dist);
}

template <typename T>
double L5(void* _a, void* _b, int n)
{
	T* a = (T*)_a, * b = (T*)_b;
	double dist = 0.0;
	for (int i = 0; i < n; i++) {
		dist += pow(fabs(a[i] - b[i]), 5);
	}
	return pow(dist, 0.2);
}

template <typename T>
double Linf(void* _a, void* _b, int n)
{
	T* a = (T*)_a, * b = (T*)_b;
	double dist = 0.0;
	for (int i = 0; i < n; i++) {
		dist = max<double>(dist, fabs(a[i] - b[i]));
	}
	return dist;
}

template <typename T>
double Lstr(void* _a, void* _b, int n)
{
	T* a = (T*)_a, * b = (T*)_b;
	auto n1 = strlen(a);
	auto n2 = strlen(b);
	vector<vector<int>> dist(n1 + 1, vector<int>(n2 + 1));
	for (size_t i = 0; i <= n1; i++)
		dist[i][0] = (int)i;
	for (size_t j = 0; j <= n2; j++)
		dist[0][j] = (int)j;
	for (size_t i = 1; i <= n1; i++) {
		for (size_t j = 1; j <= n2; j++) {
			if (a[i - 1] == b[j - 1])
				dist[i][j] = dist[i - 1][j - 1];
			else
				dist[i][j] = min({ dist[i - 1][j], dist[i][j - 1], dist[i - 1][j - 1] }) + 1;
		}
	}
	return dist[n1][n2];
}