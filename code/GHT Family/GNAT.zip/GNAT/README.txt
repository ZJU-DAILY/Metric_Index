Four parameters are needed when starting the program. 
The four parameters are as follows:
dataset filename, query filename, cost filename,the height of the tree
eg. ../dataset/mpeg_1M.txt ../dataset/mpeg_query_id.txt GNAT-mpeg-cost.txt 9 