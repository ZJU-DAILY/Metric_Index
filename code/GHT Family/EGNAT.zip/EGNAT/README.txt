Five parameters are needed when starting the program. 
The Five parameters are as follows:
dataset filename, index filename,cost filename,query filename,page size
eg. ..\..\..\dataset\LA.txt EGNAT-LA-index EGNAT-LA-cost.txt ..\..\..\dataset\LA_query.txt 4096