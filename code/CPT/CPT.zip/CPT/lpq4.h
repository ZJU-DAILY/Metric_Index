#include "MTentry.h"
#define MAXINT 32767
#include "MTnode.h"
#include "MTobject.h"
#include "lpq2.h"

#ifndef LPQ4_H
#define LPQ4_H
class LPQ4
{
public:
	LPQ4(GiSTpath p,double max):owner(p),MAXD(max)
	{
		isObject = false;
	}

	LPQ4(const LPQ4 &lpq)
	{
		q=lpq.q;
		MAXD=lpq.MAXD;
		owner=lpq.owner;
		isObject =lpq.isObject;
		o=lpq.o;
	}

	LPQENTRY2 DEQUEUE()
	{
		LPQENTRY2 e (q.top());
		q.pop();
		return e;
	}

	LPQ4(double max):MAXD(max)
	{
		isObject = false;
	}

	void INSERT(LPQENTRY2 e)
	{
		q.push(e);
		if(e.MAXD<MAXD)
			MAXD=e.MAXD;
	}


	double getMax()
	{
		return MAXD;
	}

	bool isEmpty()
	{
		return q.empty ();
	}

	GiSTpath getOwner()
	{
		return owner;
	}

	void setisObject(bool b)
	{
		isObject = b;
	}
	
	bool IsObject()
	{
		return isObject;
	}
	
	void setO(const Object& O)
	{
		o = O;
	}

	Object getO()
	{
		return o;
	}

private:
	priority_queue<LPQENTRY2> q;
	double MAXD;
	GiSTpath owner;
	bool isObject;
	Object o;
};
#endif