#include <stdio.h>
#include "MTobject.h"

extern int func;

int
Object::CompressedLength() const
{

	return sizeofObject();
}

int
Object::operator==(const Object &obj)
{
	for(int i=0; i<dimension; i++) if(x[i]!=obj.x[i]) return 0;
	return 1;
}

double
Object::distance(const Object& other) const
{
	double dist=0.0;

	compdists++;

	if (func == 1) {
		for (int i = 0; i < dimension; i++) dist += fabs(x[i] - other.x[i]); // L1
	}
	else if (func == 2) {
		for (int i = 0; i < dimension; i++) dist += pow(x[i] - other.x[i], 2); // L2
		dist = sqrt(dist);
	}
	else if (func == 5) {
		for (int i = 0;i < dimension;i++) dist += pow(fabs(x[i] - other.x[i]), 5);
		dist = pow(dist, 0.2);
	}
	else {
		for (int i = 0; i<dimension; i++) dist = MAX(dist, fabs(x[i] - other.x[i])); // Linf
	}
	return dist;
}

Object *Read()
{
	char cmdLine[1024];
	float *x=new float[dimension];

	for(int i=0; i<dimension; i++) {
		scanf("%s", cmdLine);
		x[i]=atof(cmdLine);
	}
	Object *obj=new Object(x);

	delete []x;
	return obj;
}

Object *Read(FILE *fp)
{
	char cmdLine[1024];
	float *x=new float[dimension];

	for(int i=0; i<dimension; i++) {
		fscanf(fp, "%s", cmdLine);
		x[i]=atof(cmdLine);
	}
	Object *obj=new Object(x);

	delete []x;
	return obj;
}

int sizeofObject()
{
	return dimension*sizeof(float);	// objects of constant size
}

double maxDist()
{
	return sqrt((double)dimension);
}

#ifdef PRINTING_OBJECTS
void
Object::Print(ostream& os) const
{
	os << "(" << x[0];
	for(int i=1; i<dimension; i++) os << ", " << x[i];
	os << ")";
}
#endif
