#include "MTentry.h"
//#define MAXINT 32767
#include "MTnode.h"
#include "dpq.h"
#include "MTobject.h"

#ifndef LPQENTRY2_H
#define LPQENTRY2_H

class SortEntry
{
public:
	int id;
	double dist;
	 bool operator < (const SortEntry &a) const 
	{
		return (dist<a.dist); 
	}
	SortEntry()
	{
	}
	SortEntry(const SortEntry &s)
	{
		id = s.id;
		dist = s.dist;
	}
};

class LPQENTRY2
{
public:
	LPQENTRY2(const LPQENTRY2 &e)
	{
		MIND =e.MIND;
		MAXD=e.MAXD;
		DIST=e.DIST;

		path = e.path ;
		isobject = e.isobject ;
		o=e.o;
	}

	LPQENTRY2()
	{
		isobject = false;
	}


	bool operator < (const LPQENTRY2 &a) const 
	{
		return (MIND>a.MIND); 
	}

	void setO(const Object & O)
	{
		o = O;
	}

	//MTentry * entry;
	GiSTpath path;
	double MIND;
	double MAXD;
	double DIST;
	bool isobject;
	Object o;
};
#endif

#ifndef LPQ2_H
#define LPQ2_H
class LPQ2
{
public:
	LPQ2(GiSTpath p,double max):owner(p),MAXD(max)
	{
		isObject = false;
		dpq=new DPQ(MAXD);
	}

	LPQ2(const LPQ2 &lpq)
	{
		q=lpq.q;
		MAXD=lpq.MAXD;
		owner=lpq.owner;
		dpq=new DPQ(*lpq.dpq);
		isObject =lpq.isObject;
		o=lpq.o;
	}

	LPQENTRY2 DEQUEUE()
	{
		LPQENTRY2 e (q.top());
		q.pop();
		return e;
	}

	LPQ2(double max):MAXD(max)
	{
		isObject = false;
		dpq=new DPQ(MAXD);
	}
	~LPQ2()
	{
		if(dpq!=NULL)
			delete dpq;
	}

	void INSERT(LPQENTRY2 e)
	{
		q.push(e);
		if(e.MAXD<dpq->getMAXD())
		{
			dpq->insert(e.MAXD);
		}
		if(MAXD>dpq->getMAXD())
			MAXD=dpq->getMAXD();
	}

	void insert(double d)
	{
		if(d<dpq->getMAXD())
		{
			dpq->insert(d);
		}
		if(MAXD>dpq->getMAXD())
			MAXD=dpq->getMAXD();
	}

	double getMax()
	{
		return MAXD;
	}

	bool isEmpty()
	{
		return q.empty ();
	}

	GiSTpath getOwner()
	{
		return owner;
	}

	void setisObject(bool b)
	{
		isObject = b;
	}
	
	bool IsObject()
	{
		return isObject;
	}
	
	void setO(const Object& O)
	{
		o = O;
	}

	Object getO()
	{
		return o;
	}

private:
	priority_queue<LPQENTRY2> q;
	double MAXD;
	GiSTpath owner;
	DPQ* dpq;
	bool isObject;
	Object o;
};
#endif