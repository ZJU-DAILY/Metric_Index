#include "MTentry.h"
#define MAXINT 32767
#include "MTnode.h"
#include "dpq.h"

#ifndef LPQENTRY3_H
#define LPQENTRY3_H
class LPQENTRY3
{
public:
	LPQENTRY3(const LPQENTRY3 &e)
	{
		MIND =e.MIND;
		MAXD=e.MAXD;
		DIST=e.DIST;
		path = e.path;
		if(e.entry!=NULL)
			entry =(MTentry *)e.entry->Copy ();
		else
			entry =NULL;
	}

	LPQENTRY3()
	{
		entry= NULL;
	}

	~LPQENTRY3()
	{
		if(entry!=NULL)
			delete entry;
	}

	bool operator < (const LPQENTRY3 &a) const 
	{
		return (MIND>a.MIND); 
	}

	MTentry* entry;
	double MIND;
	double MAXD;
	double DIST;
	GiSTpath path;
};
#endif

#ifndef LPQ3_H
#define LPQ3_H
class LPQ3
{
public:
	LPQ3(MTentry* o,double max):owner(o),MAXD(max)
	{
		dpq=new DPQ(MAXD);
	}

	LPQ3(const LPQ3 &lpq)
	{
		q=lpq.q;
		MAXD=lpq.MAXD;

		if(lpq.owner!=NULL)
			owner=(MTentry *)lpq.owner->Copy ();
		else
			owner=NULL;
		dpq=new DPQ(*lpq.dpq);
	}

	LPQENTRY3 DEQUEUE()
	{
		LPQENTRY3 e (q.top());
		q.pop();
		return e;
	}

	LPQ3(double max):MAXD(max)
	{
		dpq=new DPQ(MAXD);
		owner=NULL;
	}

	~LPQ3()
	{
		if(dpq!=NULL)
			delete dpq;
		if(owner!=NULL)
			delete owner;
	}

	void INSERT(LPQENTRY3 e)
	{
		q.push(e);
		if(e.MAXD<dpq->getMAXD())
		{
			dpq->insert(e.MAXD);
		}
		if(MAXD>dpq->getMAXD())
			MAXD=dpq->getMAXD();
	}

	double getMax()
	{
		return MAXD;
	}

	bool isEmpty()
	{
		return q.empty ();
	}

	MTentry* getOwner()
	{
		return owner;
	}


private:
	priority_queue<LPQENTRY3> q;
	double MAXD;
	MTentry* owner;
	DPQ* dpq;
};
#endif