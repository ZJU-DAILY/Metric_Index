#pragma once
#ifndef __CACHE__H
#define __CACHE__H

#include <iostream>
#include <vector>
#include <fstream>
#include <io.h>
#include <fcntl.h>
extern double PageFault;

extern int BLOCK_SIZE;

using namespace std;

class CacheBlock
{
public:
	unsigned long page;
	char * data;

	CacheBlock()
	{
		data = NULL;
	}

	CacheBlock(const CacheBlock& CB)
	{
		page = CB.page;
		data = CB.data;

	}

	~CacheBlock()
	{

		data = NULL;
	}

	CacheBlock& operator=(const CacheBlock& CB) 
	{ 
		page = CB.page;
		data = CB.data;

		return *this; 
	};

};

class Cache
{
	int size;
	int maxSize;
	string fname;

	int filehandle;

	vector<CacheBlock> blockVector;
public:
	Cache(string fn, int maxSize) {
		size = 0;
		this->maxSize = maxSize;
		fname = fn;
		
		filehandle = open(fname.c_str(), O_RDWR | O_BINARY);
		
	}


	~Cache()
	{
		vector<CacheBlock>::iterator it;
		for (it = blockVector.begin(); it != blockVector.end(); it++)
			delete[](*it).data;
		
		size = 0;
		
		
	}

	bool isFull()
	{
		return (size == maxSize) ? true : false;
	}

	void reset()
	{
		vector<CacheBlock>::iterator it;
		for (it = blockVector.begin(); it != blockVector.end(); it++)
		{
			delete[](*it).data;
			(*it).data = NULL;
		}			
		size = 0;
		blockVector.clear();
	}

	char* getBlock(unsigned long page)
	{
		bool flag = false; int position = 0;
		vector<CacheBlock>::iterator it;
		for (it = blockVector.begin(), position = 0; it != blockVector.end(); it++, position++)
			if ((*it).page == page)
			{
				if (position != 0)
					advanceBlock(position);
				flag = true;
				return blockVector[0].data;
			}
		if (!flag)
		{
			PageFault++;
			CacheBlock curBlock;
			curBlock.page = page;
			curBlock.data = new char[BLOCK_SIZE];
			_lseeki64(filehandle, (long long)page*BLOCK_SIZE, SEEK_SET);
			read(filehandle, curBlock.data, BLOCK_SIZE);
			
			addBlock(curBlock);
		}
		return blockVector[0].data;
	}

	void addBlock(CacheBlock newBlock) 
	{
		if (size + 1>maxSize)
			lruStrategy(newBlock);
		else
		{
			blockVector.insert(blockVector.begin(), newBlock);
			size++;
		}
	}

	void lruStrategy(CacheBlock newBlock) 
	{
		int position = maxSize - 1;

		delete[] blockVector[position].data;
		blockVector.erase(blockVector.begin() + position);
		blockVector.insert(blockVector.begin(), newBlock);
	}

	void advanceBlock(int position) 
	{
		CacheBlock recBlock = blockVector[position];

		blockVector.erase(blockVector.begin() + position);
		blockVector.insert(blockVector.begin(), recBlock);
	}
};

#endif