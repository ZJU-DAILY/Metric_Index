﻿#include <stdio.h>
#include <fstream>
#include <time.h>
#include <malloc.h>
#include <sys/stat.h>
#ifdef UNIX
#include <unistd.h>
#include <ctype.h>
#endif

#include "MT.h"
#include "MTpredicate.h"
#include <string>
#include <stack>
#include <queue>
#include "lpq2.h"
#include <map>
#include "TableLine.h"
#include "Cache.h"

using namespace std;

#define MAX(x, y) ((x>y)? (x): (y))
#define IndObjs 11648


int dimension, dataNum, func, pivotNum;
int compdists = 0;
double IOread, IOwrite;
int objs;

double PageFault = 0;

language query_language=FUZZY_STANDARD;
dist2sim hfunction=LINEAR;

extern double MIN_UTIL;
extern pp_function PROMOTE_PART_FUNCTION;
extern pv_function PROMOTE_VOTE_FUNCTION;
extern pp_function SECONDARY_PART_FUNCTION;
extern r_function RADIUS_FUNCTION;
extern int NUM_CANDIDATES;
extern s_function SPLIT_FUNCTION;

MT *gist=NULL;

int debug=0;

// close the tree and delete it
void
CommandClose()
{
	if(gist) {
		delete gist;
		gist=NULL;
	}
}

// create a new tree and open it
void
CommandCreate(const char *method, const char *table)
{
	CommandClose();
	if(!strcmp(method, "mtree")) gist=new MT;
	else {
		cerr << "The only supported method is mtree.\n";
		return;
	}
	gist->Create(table);
	if(!gist->IsOpen()) {
		cout << "Error opening index.\n";
		delete gist;
		return;
	}
	cout << "Table " << table << " created as type " << method << ".\n";
}

// delete the tree from disk
void
CommandDrop(const char *table)
{
	if (unlink(table)) cout << "There is no table by that name.\n";
	else cout << "Table " << table << " dropped.\n";
}

// open the specified tree
void
CommandOpen(const char *method, const char *table)
{
	CommandClose();
	if(!strcmp(method, "mtree")) gist=new MT;
	else {
		cerr << "The only supported method is mtree.\n";
		return;
	}
	gist->Open(table);
	if(!gist->IsOpen()) {
		delete gist;
		cout << "Error opening table.\n";
		return;
	}
}

// execute a nearest neighbor query
void
CommandNearest(const TopQuery &query)
{

	MTentry **results=gist->TopSearch(query);

	for(unsigned int i=0; i<query.k; i++) {
		MTentry *e=results[i];
		cout << e;

		delete e;
		objs++;
	}

	delete []results;
}

// execute a range query
void
CommandSelect(MTquery& query)
{
	GiSTlist<MTentry *> list=gist->RangeSearch(query);

	while(!list.IsEmpty()) {
		MTentry *e=list.RemoveFront();
		delete e;
		objs++;
	}
}

// delete the objects satisfying the predicate
void
CommandDelete(const GiSTpredicate& pred)
{
	gist->Delete(pred);
}

// insert an object in the tree
void
CommandInsert(const MTkey& key, int ptr)
{
	gist->Insert(MTentry(key, (GiSTpage)ptr));
}

// use the BulkLoading alogrithm to create the tree
void
CommandLoad(const char *table, MTentry **data, int n)
{
	CommandDrop(table);
	CommandCreate("mtree", table);

	printf("MinUtil=%f\n", MIN_UTIL);
	for (int i = 0;i < dataNum;i++)
	{ 
		gist->Insert(*data[i]);
	}
}

// close the tree and exit
void
CommandQuit()
{
	CommandClose();
	cout << "Goodbye.\n";
}

// print the prompt
void
CommandPrompt()
{
	cout << "MTree> ";
	cout.flush();
}

// activate the debug mode (currently unavailable)
void
CommandDebug()
{
	debug=!debug;
	cout << "Debugging Output ";
	cout << (debug ? "ON\n" : "OFF\n");
}

// print the help file (currently unavailable)
void
CommandHelp()
{
	ifstream is("MTree.help");
	char c;

	while(is.get(c)) cout << c;
}

// perform a check of the nodes of the tree
void
CommandCheck()
{
	GiSTpath path;
	path.MakeRoot();
	gist->CheckNode(path, NULL);
}

// print a dump of each node of the tree
void
CommandDump()
{
	GiSTpath path;
	path.MakeRoot();
#ifdef PRINTING_OBJECTS
	gist->DumpNode(cout, path);
#endif
}

// collect and print statistics on the tree
void
CommandStats()
{
	gist->CollectStats();
}

void rangequery(Object q, double radius)
{
	GiSTpath p ; 
	p.MakeRoot();
	stack<GiSTpath> s;
	s.push(p);
	vector<vector<double>> result;
	vector<GiSTpage> result2;
	vector<double> temp;
	while(!s.empty())
	{
		MTnode *node=(MTnode*) gist->ReadNode(s.top());
		s.pop();
		if(node->IsLeaf())
		{
			double parentDist = 0;
			for (int i = 0; i<node->NumEntries(); i++)
			{
				if (((MTentry *)(*node)[i].Ptr())->Key()->distance == 0)
				{
					parentDist = ((MTentry *)(*node)[i].Ptr())->object().distance(q);
					break;
				}
			}
			for(int i =0;i<node->NumEntries();i++)
			{
				if (parentDist - ((MTentry *)(*node)[i].Ptr())->Key()->distance <= radius) {
					if (((MTentry *)(*node)[i].Ptr())->object().distance(q) <= radius) {
						for (int j = 0; j < dimension; j++)
							temp.push_back(((MTentry *)(*node)[i].Ptr())->object().x[j]);
						result.push_back(temp);
						temp.clear();
						result2.push_back(((MTentry *)(*node)[i].Ptr())->Ptr());
					}
				}
			}
		}
		else
		{
			p=node->Path ();
			for(int i =0;i<node->NumEntries();i++)
			{
				if(((MTentry *)(*node)[i].Ptr())->object().distance(q)-((MTentry *)(*node)[i].Ptr())->Key()->maxradius()<=radius)
				{
					p.MakeChild(((MTentry *)(*node)[i].Ptr())->Ptr());
					s.push(p);
					p.MakeParent();
				}
			}
		}

		node = NULL;
	}	
	cout << "answer set:" << result.size() << endl;
	for (int i = 0; i < result.size(); i++) {
		for (int j = 0; j < dimension; j++)
			cout << result[i][j] << " ";
		cout << endl;
	}

	cout << "answer set:" << result2.size() << endl;
	for (int i = 0; i < result.size(); i++)
		cout << result2[i] << " ";
	cout << endl;
}

double kNN(Object q, int k)
{
	priority_queue<LPQENTRY2> pq;	// min heap
	vector<SortEntry> result;
	double kdist = MAXREAL;

	GiSTpath p ; 
	p.MakeRoot();
	LPQENTRY2 e;
	e.path = p;
	e.MIND = 0;
	pq.push(e);

	while(!pq.empty())
	{
		if(pq.top().MIND>=kdist)
		{
			break;
		}

		MTnode * node = (MTnode *) gist->ReadNode(pq.top().path);
		pq.pop();
		if(node->IsLeaf())
		{
			for(int i =0;i<node->NumEntries();i++)
			{
				SortEntry e;
				e.dist = ((MTentry *)(*node)[i].Ptr())->object().distance(q);				
				if(e.dist<=kdist)
				{
					e.id = ((MTentry *)(*node)[i].Ptr())->Ptr();
					result.push_back(e);
					if(result.size()>=k)
					{
						sort(result.begin(),result.end());
						if(result.size()>k)
							result.pop_back();
						kdist = result[k-1].dist;
					}
				}
			}
		}
		else
		{
			p=node->Path ();
			for(int i =0;i<node->NumEntries();i++)
			{
				LPQENTRY2 e;
				p.MakeChild(((MTentry *)(*node)[i].Ptr())->Ptr());
				e.path =p;
				p.MakeParent();
				e.MIND=((MTentry *)(*node)[i].Ptr())->object().distance(q)-((MTentry *)(*node)[i].Ptr())->Key()->maxradius();
				if(e.MIND<=kdist)
				{
					pq.push(e);					
				}
			}
		}
		delete node;
		node = NULL;
	}
	return result[k - 1].dist;
}


int CACHE_SIZE = 32;
int BLOCK_SIZE = 4096;
Cache *cache;

TableLine ** teSet;

unsigned long * sequence;
int * pivotSeq;


MTentry **pivotSet;
MTentry **entries;

// provide non-repeated pivot selecting
void getNonRepeatedRandomNum()
{
	srand((unsigned int)time(NULL));
	for (unsigned long i = 0; i < dataNum; i++) {
		sequence[i] = i;
	}
	int end = dataNum;
	int num;
	for (int i = 0; i < pivotNum; i++) {
		num = rand() % end;
		pivotSeq[i] = sequence[num];
		sequence[num] = sequence[end - 1];
		end--;
	}
	sort(pivotSeq, pivotSeq + pivotNum);
}


#define MAXREAL 1e20
#define num_cand 40
int * cand;



void ReadPivots(const char* pname,int pivotNum){
	pivotSeq = new int[pivotNum];
	FILE* pivot = fopen(pname, "r");

	for (int i = 0; i < pivotNum; i++) {
		fscanf(pivot, "%d", &pivotSeq[i]);
	}
	fclose(pivot);
}

clock_t buidindex(string inputfile,string outputfile,string pname)
{
	ifstream in(inputfile);
	in >> dimension >> dataNum >> func;
	dimension = dimension;
	dataNum = dataNum;

	entries = new MTentry*[dataNum];
	
	for (int i = 0; i<dataNum; i++) {
		float * obj = new float[dimension];
		for (int j = 0; j<dimension; j++)
		{
			in >> obj[j];
		}
		
		Object ob(obj);
		entries[i] = new MTentry(MTkey(ob, 0, 0), i);
		delete[] obj;
	}
	in.close();

	pivotSet = new MTentry*[pivotNum];
	ReadPivots(pname.c_str(),pivotNum);
	for (int i = 0; i < pivotNum; i++) {
		pivotSet[i] = new MTentry(*entries[pivotSeq[i]]);
	}

	
	clock_t begin = clock();
	compdists = 0;

	CommandLoad(outputfile.c_str(), entries, dataNum);

	for (int i = 0; i < dataNum; i++) delete entries[i];
	delete[]entries;

	
	return begin;
}


void buildTable(MTentry **ps, MTentry **es)
{
	for (int j = 0; j < dataNum; j++) {
		teSet[j] = new TableLine();
		teSet[j]->setObjId(j);
		teSet[j]->setPath(es[j]->Ptr());
		teSet[j]->setPosition(es[j]->Position());
		for (int k = 0; k < pivotNum; k++) {
			teSet[j]->setDistance(ps[k]->Key()->object().distance(es[j]->Key()->object()), k);
		}
	}
}
MTentry **entrySet;

void buildCPT()
{
	cout << "build CPT start." << endl;
	
	unsigned long pivotIndex = 0;
	unsigned long randomPivotIndex = 0;
	unsigned long entryIndex = 0;

	teSet = (TableLine **)malloc(sizeof(TableLine *) * dataNum);
	sequence = (unsigned long *)malloc(sizeof(unsigned long) * dataNum);
	pivotSeq = (int *)malloc(sizeof(unsigned long) * pivotNum);

	GiSTpath p;
	p.MakeRoot();
	stack<GiSTpath> s;
	s.push(p);

	while (!s.empty())
	{
		MTnode *node = (MTnode*)gist->ReadNode(s.top());

		if (node->IsLeaf())
		{
			for (int i = 0; i < node->NumEntries(); i++)
			{
				teSet[entryIndex] = new TableLine();
				teSet[entryIndex]->setObjId(entryIndex);
				teSet[entryIndex]->setPath(s.top().Page());
				teSet[entryIndex]->setPosition(i);
				for (int k = 0; k < pivotNum; k++) {
					teSet[entryIndex]->setDistance(pivotSet[k]->Key()->object().distance(((MTentry *)(*node)[i].Ptr())->Key()->object()), k);
				}
				
				entryIndex++;
			}
			s.pop();
		}
		else
		{
			s.pop();
			p = node->Path();
			for (int i = 0; i <node->NumEntries(); i++)
			{
				p.MakeChild(((MTentry *)(*node)[i].Ptr())->Ptr());
				s.push(p);
				p.MakeParent();
			}
		}
		delete node;
		node = NULL;
	}


	cout << "build CPT end." << endl;
}


double CPT_kNNQuery(Object q, int k)
{
	map<int, double> pivotQueryDist;
	for (int i = 0; i < pivotNum; i++) {
		pivotQueryDist[i] = pivotSet[i]->Key()->object().distance(q);
	}
	double tempdist;
	double kdist = MAXREAL;
	bool next;
	vector<SortEntry> result;
	MTnode *node = NULL;
	GiSTpage org =0;
	for(int i = 0; i < dataNum; i++)
	{
		next = false;
		for (int p = 0; p < pivotNum; p++) {
			if (fabs(pivotQueryDist[p] - teSet[i]->getDistance(p)) > kdist) {
				next = true;
				break;
			}
		}
		if (!next)
		{
			GiSTpage pa = teSet[i]->getPath();
			int pos = teSet[i]->getPosition();
			if (pa != org)
			{
				if(node!=NULL)
					delete node;
				org = pa;				
				GiSTpath path;
				path.MakeChild(pa);
				node = (MTnode*)gist->ReadNode(path);
			}
			tempdist = q.distance(((MTentry *)(*node)[pos].Ptr())->Key()->object());
			if (tempdist <= kdist) {
				SortEntry s;
				s.dist = tempdist;
				result.push_back(s);
				sort(result.begin(), result.end());
				if (result.size() > k) {
					result.pop_back();
				}
				if (result.size() >= k)
					kdist = result.back().dist;
			}
			
		}
	}
	if (node != NULL)
		delete node;
	return result.back().dist;
}


int CPT_rangeQuery(Object q, double radius)
{
	vector<int> result;
	double* pivotQueryDist = new double[pivotNum];
	for (int i = 0; i < pivotNum; i++) {
		pivotQueryDist[i] = pivotSet[i]->Key()->object().distance(q);
	}
	double tempdist;
	bool next;
	MTnode *node = NULL;
	GiSTpage org = 0;
	for (int j = 0; j <dataNum; j++) {
		next = false;
		for (int p = 0; p < pivotNum; p++) {
			if (fabs(pivotQueryDist[p] - teSet[j]->getDistance(p)) > radius) {
				next = true;
				break;
			}
		}
		if (!next) {
			GiSTpage pa = teSet[j]->getPath();
			int pos = teSet[j]->getPosition();
			if (pa != org)
			{
				if (node != NULL)
					delete node;
				org = pa;
				GiSTpath path;
				path.MakeChild(pa);
				node = (MTnode*)gist->ReadNode(path);
			}
			tempdist = ((MTentry *)(*node)[pos].Ptr())->object().distance(q);
			if (tempdist <= radius) {
				result.push_back(j);
			}
		}
	}
	delete[] pivotQueryDist;
	if (node != NULL)
		delete node;
	return result.size();
}

double CPT_kNNQuery_test(Object q, int k)
{
	vector<SortEntry> result;
	map<GiSTpage, MTnode> pn;
	map<int, double> pivotQueryDist;
	for (int i = 0; i < pivotNum; i++) {
		pivotQueryDist[i] = pivotSet[i]->Key()->object().distance(q);
	}
	double tempdist;
	bool next;
	double kdist = MAXREAL;
	for (int j = 0; j < dataNum; j++) {
		next = false;
		for (int p = 0; p < pivotNum; p++) {
			if (fabs(pivotQueryDist[p] - teSet[j]->getDistance(p)) > kdist) {
				next = true;
				break;
			}
		}
		if (!next) 
		{
			GiSTpage pa = teSet[j]->getPath();
			int pos = teSet[j]->getPosition();
			MTnode *nod;
		
			{
				char *buf = new char[gist->Store()->PageSize()];
				GiSTnode *node = gist->NewNode((GiST *)gist);
				gist->Store()->ReadCache(pa, buf, cache);
				node->Unpack(buf);
				delete[]buf;
				nod = (MTnode *)node;
			}
			tempdist = ((MTentry *)(*nod)[pos].Ptr())->object().distance(q);
			
			if (tempdist <= kdist) {
				SortEntry s;
				s.dist = tempdist;
				result.push_back(s);
				sort(result.begin(), result.end());
				if (result.size() > k) {
					result.pop_back();
				}
				if (result.size() >= k)
					kdist = result.back().dist;
			}
			
		}
	}

	printf("answer set: %d\n", result.size());
	return kdist;
}



void saveIndex(TableLine ** t, const char *fname)
{
	long int j, i;
	FILE *fp;

	if ((fp = fopen(fname, "wb")) == NULL)
	{
		fprintf(stderr, "Error opening output file\n");
		exit(-1);
	}
	int oid, pos;
	GiSTpage page;
	double d;
	for (i = 0; i < dataNum; i++) {
		oid = teSet[i]->getObjId();
		page = teSet[i]->getPath();
		pos = teSet[i]->getPosition();
		fwrite(&oid, sizeof(int), 1, fp);
		fwrite(&pos, sizeof(int), 1, fp);
		fwrite(&page, sizeof(GiSTpage), 1, fp);
		for (j = 0; j < pivotNum; j++) {
			d = teSet[i]->getDistance(j);
			fwrite(&d, sizeof(double), 1, fp);
		}
	}
	fclose(fp);
}


void main(int argc, char** argv)
{

	clock_t begin, buildEnd, queryEnd;
	double buildComp, queryComp;
	struct _stati64 sdata1;
	struct _stati64 sdata2;
	
	string output = "mtree.txt"; // the path to store the mtree index used in CPT
	

	double querypagefault;
	
	cout << "main start." << endl;

	string input = argv[1]; // the input data file
	string pname = argv[2]; // the input pivot file
	string indexfile = argv[3]; // the path to store the table used in CPT
	FILE * f = fopen(argv[4], "w"); //  the path to store the cost
	querydata = argv[5];  // the path of input query data
	BLOCK_SIZE = atoi(argv[6]);  // the block size of M-tree
	int pn = atoi(argv[7]);  //the number of pivots

	double radius[7];
	int kvalues[] = { 1, 5, 10, 20, 50, 100 };
	char * querydata;
	
	if (input.find("LA") != -1) {
		double r[] = { 473, 692, 989, 1409, 1875, 2314, 3096 };
		memcpy(radius, r, sizeof(r));
		dimension = 2;
		
	}
	else if (input.find("integer") != -1) {
		double r[] = { 2321, 2733, 3229, 3843, 4614, 5613, 7090 };
		memcpy(radius, r, sizeof(r));
		dimension = 20;
		
	}
	else if (input.find("mpeg_1M") != -1) {
		double r[] = { 3838, 4092, 4399, 4773, 5241, 5904, 7104 };
		memcpy(radius, r, sizeof(r));
		dimension = 282;
		
	}
	else if (input.find("sf") != -1) {
		double r[] = { 100, 200, 300, 400, 500, 600, 700 };
		memcpy(radius, r, sizeof(r));
	}

	

	/************* building the CPT Index******************/
	pivotNum = pn;
	fprintf(f, "pivotnum: %d\n", pn);
	IOread = 0;
	IOwrite = 0;
	compdists = 0;
	MIN_UTIL = 0.01;
	begin = buidindex(input, output,pname);
	cout << "finish building M-tree" << endl;
	CommandOpen("mtree", output.c_str());
	buildCPT();

	cout << "finish building" << endl;
	buildEnd = clock() - begin;
	buildComp = compdists;
	querypagefault = IOread + IOwrite;
	fprintf(f, "building...\n");
	fprintf(f, "finished... %f build time\n", (double)buildEnd / CLOCKS_PER_SEC);
	fprintf(f, "finished... %f distances computed\n", buildComp);
	fprintf(f, "finished... %f IOreads\n", IOread);
	fprintf(f, "finished... %f IOwrites\n", IOwrite);

	CommandClose();

	saveIndex(teSet, indexfile.c_str());
	_stati64(output.c_str(), &sdata1);
	_stati64(indexfile.c_str(), &sdata2);
	fprintf(f, "saved... %lli bytes\n", (long long)(sdata1.st_size + sdata2.st_size));
	fflush(f);
	
	/************* range query and kNN query******************/
	// control in-memory size	

	fprintf(f, "\nquerying...\n");
	CommandOpen("mtree", output.c_str());

	cache = new Cache(output, CACHE_SIZE);
	
	FILE * fp;
	int qcount = 100;
	double rad;
	Object* o = new Object();
	cout << "start knnSearching......" << endl;
	for (int k = 0; k < 6; k++) {
		fp = fopen(querydata, "r");
		cache->reset();
		begin = clock();
		compdists = 0;
		IOread = 0;
		rad = 0;
		for (int j = 0; j < qcount; j++)
		{
			
			for (int i = 0;i < dimension;i++)
			{
				fscanf(fp, "%f", &o->x[i]);
			}
			fscanf(fp, "\n");
			rad += CPT_kNNQuery(*o, kvalues[k]);  //KNN query
		}
		queryEnd = clock() - begin;
		queryComp = compdists;
		fprintf(f, "k: %d\n", k);

		fprintf(f, "finished... %f query time\n", (double)queryEnd / CLOCKS_PER_SEC / qcount);
		fprintf(f, "finished... %f distances computed\n", queryComp / qcount);
		fprintf(f, "finished... %f IO times\n", IOread / qcount);
		fprintf(f, "finished... %f radius\n", rad / qcount);
		
		fflush(f);
		fclose(fp);
	}
	cout << "start rangeSearching......" << endl;
	for (int k = 0; k < 7; ++k) {
		fp = fopen(querydata, "r");
		cache->reset();
		begin = clock();
		compdists = 0;
		IOread = 0;
		rad = 0;
		for (int j = 0; j < qcount; j++)
		{
			
			for (int i = 0;i < dimension;i++)
			{
				fscanf(fp, "%f", &o->x[i]);
			}
			fscanf(fp, "\n");
			rad += CPT_rangeQuery(*o, radius[k]); // Range Query
		}
		queryEnd = clock() - begin;
		queryComp = compdists;
		fprintf(f, "r: %f\n", radius[k]);
		fprintf(f, "finished... %f query time\n", (double)queryEnd / CLOCKS_PER_SEC / qcount);
		fprintf(f, "finished... %f distances computed\n", queryComp / qcount);
		fprintf(f, "finished... %f IO times\n", IOread / qcount);
		fprintf(f, "finished... %f objs\n", rad / qcount);
		fflush(f);
		fclose(fp);
	}
	free(teSet);
	free(sequence);
	free(pivotSeq);

	CommandClose();
	delete cache;
	fprintf(f, "\n");
	cout << "main end." << endl;
	/************************************************************/

}

