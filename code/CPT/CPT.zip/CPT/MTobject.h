#ifndef MTOBJECT_H
#define MTOBJECT_H

extern int compdists;
extern int dimension;

#ifndef MIN
#define MIN(x, y) ((x<y)? (x): (y))
#define MAX(x, y) ((x>y)? (x): (y))
#endif

#include <stdio.h>
#include <string.h>
#include "GiSTdefs.h"

class Object : public GiSTobject	// the DB object class
{
public:
	float *x;	// the coords
//	long wasted_space[100];	// only for debug purposes
	Object() { x=new float[dimension]; };	// default constructor (needed)
	Object(const Object& obj) { x=new float[dimension]; for(int i=0; i<dimension; i++) x[i]=obj.x[i]; };	// copy constructor (needed)
	Object(char *key) {	x=new float[dimension]; memcpy(x, key, dimension*sizeof(float)); };	// member constructor (needed)
	Object(float *p_x) { x=new float[dimension]; for(int i=0; i<dimension; i++) x[i]=p_x[i]; };	// member constructor (needed)
	~Object() { delete []x; }	// destructor
	Object& operator=(const Object& obj) { if(x==NULL) x = new float[dimension]; for (int i = 0; i < dimension; i++) x[i] = obj.x[i]; return *this; };	// assignment operator (needed)
	double area(double r) {	// only needed for statistic purposes (dependent on the metric, not applicable for non-vector metric spaces)
		double a=1;

		for(int i=0; i<dimension; i++) a*=(MIN(x[i]+r, 1)-MAX(x[i]-r, 0));
		return a;
	};
	int operator==(const Object& obj);	// equality operator (needed)
	int operator!=(const Object& obj) { return !(*this==obj); };	// inequality operator (needed)
	double distance(const Object& other) const;	// distance method (needed)
	int CompressedLength() const;	// return the compressed size of this object
	void Compress(char *key) { memcpy(key, x, dimension*sizeof(float)); };	// object compression
#ifdef PRINTING_OBJECTS
	void Print(ostream& os) const;
#endif
};

double maxDist();	// return the maximum value for the distance between two objects
int sizeofObject();	// return the compressed size of each object (0 if objects have different sizes)
Object *Read();	// read an object from standard input
Object *Read(FILE *fp);	// read an object from a file

#endif
