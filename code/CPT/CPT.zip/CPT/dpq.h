#include <queue>
#define MAXREAL 1e20
#ifndef DPQ_H
#define DPQ_H
extern int num;
class DPQ
{
public:
	DPQ(double max):MAXD(max)
	{
		a= new double[num];
		for(int i  =0;i<num;i++)
			a[i]=MAXREAL;
	}
	DPQ(const DPQ &d)
	{
		MAXD=d.MAXD;
		a=new double[num];
		for(int i  =0;i<num;i++)
			a[i]=d.a[i];
	}

	~DPQ()
	{
		if(a!=NULL)
			delete[] a;
	}
	int findp(double e)
	{
		for(int i =0;i<num;i++)
		{
			if(e<a[i])
				return i;
		}
	}
	void insert(double e)
	{
		int index;
		if(e < MAXD)
		{
			index= findp(e);
			if(index == num-1)
				a[num-1]=e;
			else
			{
				for(int i = num-2;i>=index;i--)
					a[i+1]=a[i];
				a[index]=e;
			}
		}
		if(MAXD>a[num-1])
			MAXD=a[num-1];
	}
	double getMAXD()
	{
		return MAXD;
	}
private:
	double* a;
	double MAXD;
};
#endif