#ifndef CDF_H
#define CDF_H

long double cdf(long double x);
long double GL(long double a, long double b);
long double f(long double x);

#endif