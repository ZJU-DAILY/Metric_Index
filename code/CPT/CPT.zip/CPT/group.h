#ifndef GROUP_H
#define GROUP_H
#include "MTentry.h"
class GROUP
{
public:
	GROUP(int num)
	{
		numberofentry = num;
		entries = new MTentry*[num];
	}
	~GROUP()
	{
		for(int i = 0;i<numberofentry;i++)
		{
			if(entries[i]!=NULL)
			{
				delete entries[i];
			}
		}
		if(entries!=NULL)
			delete entries;
		if(RO!=NULL)
			delete RO;
	}

	MTentry ** entries;
	int numberofentry;
	MTentry *RO;
	
};
#endif