#ifndef __HEAPELEMENT__H
#define __HEAPELEMENT__H

#include "MTentry.h"
#include "GiSTpath.h"
class HeapElement
{
public:
	MTentry* e;
	double dist;
	GiSTpath path;
	bool operator < (const HeapElement &e2) const 
	{ 
		return (dist>e2.dist);
	}
};

#endif