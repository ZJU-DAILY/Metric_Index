#ifndef __GENERAL_DEFINITION
#define __GENERAL_DEFINITION

#include <stdio.h>
#include <ctype.h>
//----BlockFile, CachedBlockFile, Cache---------------------
#define BFHEAD_LENGTH (sizeof(int)*2)    //file header size

#define TRUE 1
#define FALSE 0

#define SEEK_CUR 1
#define SEEK_SET 0
#define SEEK_END 2

typedef char Block[];
//-------------------All-------------------------------------
#define MAXREAL         1e20
#define FLOATZERO       1e-20
#define MAX_DIMENSION   256

#define DIMENSION 2

#define TRUE 1
#define FALSE 0

#define min(a, b) (((a) < (b))? (a) : (b)  )
#define max(a, b) (((a) > (b))? (a) : (b)  )


#include <string.h>

extern int **table;
#define MAX_LEN 100	

//-------------------Class and other data types--------------
class BlockFile;  //for BlockFile definition
class Cache;
class Cacheable   //inherit this class if you wish to design an external
                  //memory structure that can be cached
{
public:
	BlockFile *file;
	Cache *cache;
};
  //==========================================================
class CmdIntrpr  //this is the class of command interpretor.  for a new rtree decescendent
                  //inherit this class to obtain tailored command interpretor
{
public:
	int cnfrm_cmd(char *_msg)
	{ char c = ' ';
	  while (c != 'N' && c != 'Y')
	  { printf("%s (y/n)?", _msg);
	    c = getchar(); 
		char tmp;
		while ((tmp = getchar()) != '\n');
		c = toupper(c); }
	  if (c == 'N') return 0; else return 1; }
  
	void get_cmd(char *_msg, char *_cmd)
	{ printf("%s", _msg);  
	  char *c = _cmd;
	  while (((*c) = getchar()) != '\n')
	    c++;
	  *c = '\0'; } 

	virtual bool build_tree(char *_tree_fname, char *_data_fname, int _b_len, int _dim, int _csize) = 0;
	virtual void free_tree() = 0;
	virtual int qry_sngle(double *_mbr, int *_io_count) = 0;
	
	virtual void run() = 0;
	virtual void version() = 0;
};
  //==========================================================
enum SECTION {OVERLAP, INSIDE, S_NONE};
enum R_OVERFLOW {SPLIT, REINSERT, NONE};
enum R_DELETE {NOTFOUND,NORMAL,ERASED};
typedef double *floatptr;
  //==========================================================
struct SortMbr
{
    int dimension;
    double *mbr;
    double *center;
    int index;
};

struct BranchList
{
    int entry_number;
    double mindist;
    double minmaxdist;
    bool section;
};

//-----Global Functions--------------------------------------
void error(char *_errmsg, bool _terminate);

double area(int dimension, double *mbr);
double margin(int dimension, double *mbr);
double overlap(int dimension, double *r1, double *r2);
double* overlapRect(int dimension, double *r1, double *r2);
double objectDIST(double *p1, double *p2);
double MINMAXDIST(double *Point, double *bounces);
double MINDIST(double *Point, double *bounces, int Pdim);
double MAXDIST(double *p, double *bounces, int dim);
double MbrMINDIST(double *_m1, double *_m2, int _dim);
double MbrMAXDIST(double *_m1, double *_m2, int _dim);



double CDF_max(double *point, double *bounces, double r, int n, int p, int dim, double alpha);
double dist_step1(double *q, double *bounces, int n, int p, int dim);


bool inside(double &p, double &lb, double &ub);
void enlarge(int dimension, double **mbr, double *r1, double *r2);
bool is_inside(int dimension, double *p, double *mbr);
int pruneBrunchList(double *nearest_distanz, const void *activebrunchList, 
		    int n);
bool section(int dimension, double *mbr1, double *mbr2);
bool section_c(int dimension, double *mbr1, double *center, double radius);

int sort_lower_mbr(const void *d1, const void *d2);
int sort_upper_mbr(const void *d1, const void *d2);
int sort_center_mbr(const void *d1, const void *d2);
int sortmindist(const void *element1, const void *element2);

double get_dist(char* s, char*t);


// ***************************************************************************
// ** Datengenerierung                                                      **
// ***************************************************************************



#ifdef CYGWIN
	#define MAXINT 2147483647
#else
	#define MAXINT 32767
#endif

#define sqr(a) ((a)*(a))



void InitStatistics(int Dimensions);


void EnterStatistics(int Dimensions,double* x);


void OutputStatistics(int Dimensions);


double RandomEqual(double min,double max);


double RandomPeak(double min,double max,int dim);


double RandomNormal(double med,double var);

void GenerateDataEqually(FILE* f,int Count,int Dimensions);


void GenerateDataCorrelated(FILE* f,int Count,int Dimensions);


void GenerateDataAnticorrelated(FILE* f,int Count,int Dimensions);



void GenerateData(int Dimensions,char Distribution,int Count,char* FileName);


double uniform(double _min, double _max);


double gaussian (double mean, double sigma);

double zipf(double x1, double x2, double p);


#ifdef UNIX
void strupr(char *_msg);
#endif
//-----------------------------------------------------------
#endif