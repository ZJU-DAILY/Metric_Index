#ifndef __NODEELEMENT__H
#define __NODEELEMENT__H

#include "MTnode.h"
#include "MTobject.h"

class NodeElement
{
public:
	MTnode* e;
	double dist;
	bool operator < (const NodeElement &e2) const 
	{ 
		return (dist>e2.dist);
	}
};
class NodeElement2
{
public:
	MTnode* e;
	Object obj;
	double maxradium;
	double dist;
	bool operator < (const NodeElement2 &e2) const 
	{ 
		return (dist>e2.dist);
	}
};


#endif