#include "GiSTdefs.h"

extern int pivotNum;

class TableLine
{
private:
	GiSTpage path;
	int position;

	int objId;

	double * distance; // distance between pivot and object

public:
	TableLine() { distance = (double *)malloc(sizeof(double) * pivotNum); };
	GiSTpage & getPath() { return path; }
	int & getPosition() { return position; }
	int & getObjId() { return objId; }
	double & getDistance(int i) { return distance[i]; }
	void setPath(GiSTpage pa) { path = pa; }
	void setPosition(int pos) { position = pos; }
	void setObjId(int p) { objId = p; }
	void setDistance(double d, int i) { distance[i] = d; }
	
	~TableLine() {}
};
