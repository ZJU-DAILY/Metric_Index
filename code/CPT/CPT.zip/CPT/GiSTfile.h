#ifndef GISTFILE_H
#define GISTFILE_H

#include "GiSTstore.h"
#include "Cache.h"

extern int BLOCK_SIZE; 

// GiSTfile is a simple storage class for GiSTs to work over 
// UNIX/NT files.

class GiSTfile: public GiSTstore {
public:
  GiSTfile(): GiSTstore() {}

  void Create(const char *filename);
  void Open(const char *filename);
  void Close();

  void Read(GiSTpage page, char *buf);
  char* ReadCache(GiSTpage page,char *buf,Cache* c);
  void Write(GiSTpage page, const char *buf);
  GiSTpage Allocate();
  void Deallocate(GiSTpage page);
  void Sync() {}
  int PageSize() const { return BLOCK_SIZE; }

private:
  int fileHandle;
};

#endif
