#include "MT.h"
#include "MTpredicate.h"
#include "MTentry.h"

extern dist2sim hfunction;
extern double distr[1001];

double Dist2Sim(double dist) {
	switch(hfunction) {
		case LINEAR: return 1-dist/maxDist();
		case EXPONENTIAL: return exp(-dist);
		default: return 0;
	}
}

double Sim2Dist(double sim) {
	switch(hfunction) {
		case LINEAR: return maxDist()*(1-sim);
		case EXPONENTIAL: return -log(sim);
		default: return maxDist();
	}
}

int 
SimpleQuery::Consistent(const GiSTentry& entry)
{
	assert(entry.IsA()==MTENTRY_CLASS);
	if((grade==0)||(fabs(grade-((MTentry &)entry).Key()->distance)<=radius+((MTentry &)entry).maxradius())) {	// prune for reference point
		grade=pred->distance(((MTentry &)entry).object());
		return(grade<=radius+((MTentry &)entry).maxradius());
	}
	else return FALSE;
}

int 
SimpleQuery::NonConsistent(const GiSTentry& entry)
{
	assert(entry.IsA()==MTENTRY_CLASS);
	if((grade==0)||(fabs(grade-((MTentry &)entry).Key()->distance)>radius-((MTentry &)entry).maxradius())) {	// prune for reference point
		grade=pred->distance(((MTentry &)entry).object());
		return(grade>radius-((MTentry &)entry).maxradius());
	}
	else return FALSE;
}
