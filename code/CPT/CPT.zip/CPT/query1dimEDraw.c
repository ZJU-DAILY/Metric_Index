#include <stdio.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include <malloc.h>
/* This code is suitalbe for query original decarstin  cordination */

#define pi          3.1415926535798932
#define MAXDIS 1000000000
#define SEGLENGTH 2000
  
typedef struct disRec_
	{
	int no;
	double dis;
	} disRec;
typedef struct hisRec_
        {
        double no;
        } hisRec;

typedef struct posRec_
        {
        double x;
        double y;
        } posRec;

int power (int base, int p);

double maxValue(double x1, double x2, double x3);
double minValue(double x1, double x2, double x3);
double  minF(double  a, double b);
int max(int a, int b);
double computeStdeviation(double *x, int len);
double computeMean(double *x, int len);
double  minF(double  a, double b);
double LCSScore(double  * x, double  *y, double gap, int len1, int len2, double diffthreshold);
double calEudistance (double p1, double p2);
double maxValue(double x1, double  x2, double x3)
{
  if ((x1>=x2)&&(x1>=x3)) return x1;
  if ((x2>=x3)&&(x2>=x1)) return x2;
  if ((x3>=x1)&&(x3>=x2)) return x3;
}

double minValue(double x1, double  x2, double x3)
{
  if ((x1<=x2)&&(x1<=x3)) return x1;
  if ((x2<=x3)&&(x2<=x1)) return x2;
  if ((x3<=x1)&&(x3<=x2)) return x3;
}
int max(int a, int b)
{
  return a>b? a:b;
}
double  minF(double  a, double b)
{
  return a>b ? b:a;
}

double calEudistance (double p1, double p2)
{

  return(fabs(p1-p2));
 }
double computeStdeviation(double *x, int len)
{
  int i;
  double avg, std;
  avg=0.0;
  for (i=0; i<len; i++)
    {
      avg +=x[i];
    }
  avg /= (double)len;
  std=0.0;
  for (i=0; i<len; i++)
    {
      std += (x[i]-avg)*(x[i]-avg);
    }
  std /= (double)len;
  std = sqrt(std);
  return std;
}
double computeMean(double *x, int len)
{
  int i;
  double avg, std;
  avg=0.0;
  for (i=0; i<len; i++)
    {
      avg +=x[i];
    }
  avg /= (double)len;
  
  return avg;
}
double LCSScore(double  * x, double  *y, double gap, int len1, int len2, double diffthreshold)
{
  int M, N, i, j, k;
  double  *matchM;
  double s1, s2, s3;
  int pos1, pos2;
  double up, left, diag, maxDist;
  int pathLen;
  double diff_d, diff_h, diff_v;
  double std1, std2, diffthreshold1;
  double e1, e2;
  double score, maxScore;
  int posX, posY;
  M=len1+1;
  N=len2+1;
  
  matchM=(double  *)malloc(M*N*sizeof(double));
  if(matchM==NULL)
    { printf("not enough memory to store the matching matrix!\n"); exit(0);}
  //initalized matrix
  for (i=0; i<M; i++)
    matchM[i]=0.0;
   for(j=0; j<N; j++)
     matchM[j*M]=0.0;
  for (i=1; i<M; i++)
   {
     for (k=0; k<i; k++)
       matchM[i]+=(-calEudistance(x[k],gap));
   }
  for(j=1; j<N; j++)
    {

      for (k=0; k<j; k++)
      matchM[j*M]+=(-calEudistance(y[k], gap)); //for golbal alignment
    }
  
  maxScore=-999999;
  posX=0;
  posY=0;
  for(i=1; i<M; i++)
    for(j=1; j<N; j++)
    
      {

        diff_d=calEudistance(x[i-1], y[j-1]);
	
	
	diff_h=calEudistance(x[i-1], gap);
	diff_v=calEudistance(y[j-1], gap);

		     
	s1=matchM[(j-1)*M+(i-1)]-diff_d;
	s2=matchM[(j-1)*M+i]-diff_v;
	s3=matchM[j*M+(i-1)]-diff_h;

	matchM[j*M+i]=maxValue(s1, s2, s3);

	
      }
 
  //score=maxScore; //for local alignment
  score=matchM[(N*M-1)];
  free(matchM);
  return  ((0-score)) ; 
}

int power (int base, int p)
{
  int i, tmpV;
  if (p<0) {printf ("p must be greater than 0\n"); exit(0);}
  if (p==0) return 1;
  else
    { 
      tmpV=1;
      for (i=0; i<p; i++)
 	{
	  tmpV *=base;
        }
    }
}  
