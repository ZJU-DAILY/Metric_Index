#include <queue>
#include "MTnode.h"
#ifndef LPQENTRY_H
#define LPQENTRY_H
class LPQENTRY
{
public:
	LPQENTRY(const LPQENTRY &e)
	{
		MIND =e.MIND;
		MAXD=e.MAXD;
		DIST=e.DIST;
		entry = (MTnode*) e.entry->Copy();
	}

	LPQENTRY()
	{
		MIND=MAXD=DIST=MAXINT;
		entry=NULL;
	}
	~LPQENTRY()
	{
		if(entry!=NULL)
			delete entry;
	}
	bool operator < (const LPQENTRY &a) const 
	{
		return (MIND>a.MIND); 
	}
	MTnode * entry;
	double MIND;
	double MAXD;
	double DIST;
};
#endif

#ifndef LPQ_H
#define LPQ_H
class LPQ
{
public:
	LPQ(MTnode* node,double max):owner(node),MAXD(max){}
	LPQENTRY DEQUEUE()
	{
		LPQENTRY e (q.top());
		q.pop();
		return e;
	}
	
	void INSERT(LPQENTRY e)
	{
		q.push(e);
		if(e.MAXD<MAXD)
			MAXD =e.MAXD;
	}

	MTnode * Owner()
	{
		return owner;
	}

	double getMax()
	{
		return MAXD;
	}
private:
	priority_queue<LPQENTRY> q;
	double MAXD;
	MTnode * owner;
};
#endif