#include "Object.h"
#include <iostream>
extern int dimension;
extern double compdists;

class DistHelper {
public:
	double (*distance)(Object& obj1, Object& obj2) ;

	void setFunc(int func){
		switch (func)
		{
		case 0:distance = LiD;
			break;
		case 1:distance = L1D;
			break;
		case 2:distance = L2D;
			break;
		default:
			break;
		}
	}
	static double L1D(Object& obj1, Object& obj2) {
		double dist;
		dist = 0;
		compdists++;
		for (int i = 0; i < dimension; i++) dist += fabs(obj1.data[i] - obj2.data[i]);
		return dist;
	}

	static double L2D(Object& obj1, Object& obj2) {
		double dist;
		dist = 0;
		compdists++;
		for (int i = 0; i < dimension; i++) dist += pow(obj1.data[i] - obj2.data[i], 2); // L2
		dist = sqrt(dist);
		return dist;
	}

	static double LiD(Object& obj1, Object& obj2) {
		double dist;
		dist = 0;
		compdists++;
		for (int i = 0; i < dimension; i++) {
			double tmp = fabs(obj1.data[i] - obj2.data[i]);
			dist = dist > tmp ? dist : tmp;
		}
		return dist;
	}

};

