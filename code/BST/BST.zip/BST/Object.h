#ifndef __Object
#define __Object
#include <iostream>
class Object {
public:
	float *data;

	Object();
	Object(const Object & o);
	~Object();


	void print();
	Object operator=(const Object& other);
};
#endif

