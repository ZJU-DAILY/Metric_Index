#ifndef __BST
#define __BST

#include "Node.h"
#include "ResultSet.h"
#include <string>
#include <vector>
#include <algorithm>
extern int MaxHeight;
extern DistHelper distHelper;
using namespace std;

class BST {
protected:
	double rangeSearchInMemory(Node *node, Object query, double radius, bool show);
	void knnSearchInMemory(Node *node, Object query, int k);

public:
	Node *root;
	BST(vector<Obj> objVec);
	void preTraverse(Node *root);
	double rangeSearch(Object query,double radius);
	double knnSearch(Object query,int k);

};


#endif
