#include "Object.h"
#include<iostream>
using namespace std;

#define MIN(x, y) ((x<y)? (x): (y))
#define MAX(x, y) ((x>y)? (x): (y))

extern int func;
extern double compdists;
extern int dimension;
Object::Object(){
	data = new float[dimension];
	//data = NULL;
}

Object::Object(const Object & other) {

	if (other.data != NULL) {
		data = new float[dimension];
		for (int i = 0; i < dimension; i++)
			data[i] = other.data[i];
	}
	else
		data = NULL;
}

Object::~Object() {
	if (data != NULL) {
		delete[] data;
		data = NULL;
	}
}

void Object::print() {
	for (int i = 0; i < dimension; i++) {
		cout << data[i] << " ";
	}
}

Object Object::operator=(const Object& other) {
	if (data != NULL) {
		delete[] data;
		data = NULL;
	}
	data = new float[dimension];
	for (int i = 0; i < dimension; i++)
		data[i] = other.data[i];

	return *this;
}
