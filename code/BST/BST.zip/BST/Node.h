#ifndef __Node
#define __Node

#include <iostream>
#include <vector>
#include "dist.h"
typedef int Obj;

using namespace std;
extern Object *objs;
extern int MaxHeight;
extern int dimension;
extern double compdists;
extern DistHelper distHelper;
class Node {
public:

	Obj pl, pr;
	Node *lChild, *rChild;
	Node *Ancestor;
	double lRadius, rRadius;
	bool full;

	int num;
	Obj* bucket;

	Node() {}
	Node(vector<Obj> objVec,int h);
	void print();
	~Node();
};


#endif
