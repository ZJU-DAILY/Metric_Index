/*********************************************************************
*                                                                    *
* Copyright (c)                                                      *
* ZJU-DBL, Zhejiang University, Hangzhou, China                      *
*                                                                    *
* All Rights Reserved.                                               *
*                                                                    *
* Permission to use, copy, and distribute this software and its      *
* documentation for NON-COMMERCIAL purposes and without fee is       *
* hereby granted provided  that this copyright notice appears in     *
* all copies.                                                        *
*                                                                    *
* THE AUTHORS MAKE NO REPRESENTATIONS OR WARRANTIES ABOUT THE        *
* SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING  *
* BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,      *
* FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. THE AUTHOR  *
* SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A      *
* RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS    *
* DERIVATIVES.                                                       *
*                                                                    *
*********************************************************************/

#include<iostream>
#include<fstream>
#include<cstdlib>
#include<cmath>
#include<string>
#include<vector>
#include<ctime>
#include "BST.h"
#include"Object.h"

using namespace std;

extern ResultSet *knnResult;
double compdists = 0;
double IOread = 0;
double IOwrite = 0;
int func;
int dimension = 2;
int num_obj;
int MaxHeight;
DistHelper distHelper;
Object *objs;
Object *readObjects(char* fileName);

int main(int argc, char **argv) {
	clock_t begin = 0, buildEnd = 0, queryEnd = 0;
	double buildComp, queryComp;

	srand((unsigned)time(NULL));
	char *fileName, *costFile;
	int temp;
	fileName = argv[1];
	costFile = argv[2];
	MaxHeight = atoi(argv[4]);
	FILE *fcost = fopen(costFile, "w");
	objs = readObjects(fileName);
	vector<Obj> objVec(num_obj, 0);
	for (int i = 0; i < num_obj; i++) {
		objVec[i] = i;
	}
	compdists = 0;
	cout << "start building BST......" << endl;
	begin = clock();
	BST bst(objVec); //build BST
	buildEnd = clock() - begin;
	buildComp = compdists;
    cout<<"finish building BST......" <<endl;
	fprintf(fcost, "building...\n");
	fprintf(fcost, "finished... %f build time\n", (double)buildEnd / CLOCKS_PER_SEC);
	fprintf(fcost, "finished... %f distances computed\n", buildComp);
	fprintf(fcost, "\n\n");


	int qcount = 100;

	double radius[7];
	int kvalues[] = { 1, 5, 10, 20, 50, 100 };
	char * querydata;
	querydata = argv[3];

	if (string(fileName).find("LA") != -1) {
		double r[] = { 473, 692, 989, 1409, 1875, 2314, 3096 };
		memcpy(radius, r, sizeof(r));
		dimension = 2;
	}
	else if (string(fileName).find("integer") != -1) {
		double r[] = { 2321, 2733, 3229, 3843, 4614, 5613, 7090 };
		memcpy(radius, r, sizeof(r));
		dimension = 20;
	}
	else if (string(fileName).find("mpeg_1M") != -1) {
		double r[] = { 3838, 4092, 4399, 4773, 5241, 5904, 7104 };
		memcpy(radius, r, sizeof(r));
		dimension = 282;
	}
	else if (string(fileName).find("sf") != -1) {
		double r[] = { 100, 200, 300, 400, 500, 600, 700 };
		memcpy(radius, r, sizeof(r));
	}



	cout << "start knnSearching......" << endl;
	double radiusResult=0;

	for (int k = 0; k < 6; k++) {
		ifstream fquery(querydata, ios::in);
		begin = clock();
		compdists = 0;
		radiusResult = 0;
		for (int i = 0; i < qcount; i++) {
			Object query;
			for (int j = 0; j < dimension; j++)
			{
				fquery >> query.data[j];
			}
			double tmp = bst.knnSearch(query, kvalues[k]); //knnSearch
			radiusResult += tmp;
		}
		queryEnd = clock() - begin;
		queryComp = compdists;
		fprintf(fcost, "round %d,kvalues: %d\n", k,kvalues[k]);
		fprintf(fcost, "finished... %f query time\n", (double)queryEnd / CLOCKS_PER_SEC / qcount);
		fprintf(fcost, "finished... %f distances computed\n", queryComp / qcount);
		fprintf(fcost, "finished... %f radius\n", radiusResult / qcount);
		fprintf(fcost, "\n");
		fflush(fcost);
		fquery.close();
	}

	cout << "start rangeSearching......" << endl;
	double resNum = 0;
	for (int k = 0; k < 7; k++) {
		ifstream fquery(querydata, ios::in);
		begin = clock();
		compdists = 0;
		resNum = 0;
		for (int i = 0; i < qcount; i++) {
			Object query;
			for (int j = 0; j < dimension; j++){
				fquery >> query.data[j];
			}
			resNum += bst.rangeSearch(query, radius[k]); //rangeSearch
		}
		queryEnd = clock() - begin;
		queryComp = compdists;


		fprintf(fcost, "round %d,radius: %f\n", k,radius[k]);
		fprintf(fcost, "finished... %f query time\n", (double)queryEnd / CLOCKS_PER_SEC / qcount);
		fprintf(fcost, "finished... %f distances computed\n", queryComp / qcount);
		fprintf(fcost, "finished... %f objs\n", resNum / qcount);
		fprintf(fcost, "finished... %f IOreads\n", IOread / qcount);
		fprintf(fcost, "\n");
		fflush(fcost);
		fquery.close();
	}
	fclose(fcost);
	delete[] objs;
	return 0;
}


Object *readObjects(char* fileName) {

	ifstream fin(fileName,ios::in);
	fin >> dimension >> num_obj >> func;

	distHelper.setFunc(func);
	Object *objs = new Object[num_obj];
	for (int i = 0; i < num_obj; i++) {
		objs[i].data = new float[dimension];
		for (int j = 0; j < dimension; j++) {
			fin >> objs[i].data[j];
		}
	}
	fin.close();


	return objs;
}
