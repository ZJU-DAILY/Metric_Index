#include "BST.h"
#include <fstream>
#include <iostream>

using namespace std;

extern int func;
extern int dimension;
extern int num_obj;

ResultSet *knnResult;
BST::BST(vector<Obj> objVec) {
	Object tmpObj;

	if(objVec.size()!=0) root = new Node(objVec,1);
	else root = NULL;
}

void BST::preTraverse(Node *root) {
	if (root != NULL) {
		root->print();
		cout << endl;
		preTraverse(root->lChild);
		preTraverse(root->rChild);
	}
}


double BST::rangeSearch(Object query, double radius) {
	double resultNum=0;
	resultNum=rangeSearchInMemory(root, query, radius, false);
	return resultNum;
}


double BST::rangeSearchInMemory(Node *node, Object query, double radius, bool show) {
	double resultNum = 0;
	if (node == NULL) return resultNum;

	if (node->num < 0) {
		double dl = distHelper.distance(query, objs[node->pl]);
		if (dl <= radius) {
			resultNum++;
			if (show) {
				objs[node->pl].print();
				cout << "dist:" << dl << endl;
			}
		}

		if (node->full) {
			double dr = distHelper.distance(query, objs[node->pr]);
			if (dr <= radius) {
				resultNum++;
				if (show) {
					objs[node->pr].print();
					cout << "dist:" << dr << endl;
				}
			}
			if (dl - node->lRadius <= radius) resultNum += rangeSearchInMemory(node->lChild, query, radius, show);
			if (dr - node->rRadius <= radius) resultNum += rangeSearchInMemory(node->rChild, query, radius, show);
		}
	}
	else {
		for (int i = 0; i < node->num; i++) {
			double dist = distHelper.distance(query, objs[node->bucket[i]]);
			if (dist <= radius) resultNum++;
		}
	}
	return resultNum;
}

double BST::knnSearch(Object query, int k) {
	knnResult = new ResultSet(k);
	knnSearchInMemory(root, query, k);
	return knnResult->radius;
}

void BST::knnSearchInMemory(Node *node, Object query, int k) {
	if (node == NULL) return;
	if (node->num < 0) {
		double dl = distHelper.distance(query,objs[node->pl]);
		if (dl <= knnResult->radius) {
			resultElem elem;
			elem.obj = node->pl;
			elem.dist = dl;
			knnResult->addElem(elem);
		}
		if (node->full) {
			double dr = distHelper.distance(query, objs[node->pr]);
			if (dr <= knnResult->radius) {
				resultElem elem;
				elem.obj = node->pr;
				elem.dist = dr;
				knnResult->addElem(elem);
			}

			if (dl - node->lRadius < knnResult->radius && dr - node->rRadius < knnResult->radius) {
				if (dr <= dl) {
					knnSearchInMemory(node->rChild, query, k);
					if (dl - node->lRadius < knnResult->radius) knnSearchInMemory(node->lChild, query, k);
				}
				else {
					knnSearchInMemory(node->lChild, query, k);
					if (dr - node->rRadius < knnResult->radius) knnSearchInMemory(node->rChild, query, k);
				}
			}
			else if (dl - node->lRadius < knnResult->radius && !(dr - node->rRadius < knnResult->radius)) {
				knnSearchInMemory(node->lChild, query, k);
			}
			else if (!(dl - node->lRadius < knnResult->radius) && dr - node->rRadius < knnResult->radius) {
				knnSearchInMemory(node->rChild, query, k);
			}

		}
	}
	else {
		for (int i = 0; i < node->num; i++) {
			double dist = distHelper.distance(query, objs[node->bucket[i]]);
			if (dist <= knnResult->radius) {
				resultElem elem;
				elem.obj = node->bucket[i];
				elem.dist = dist;
				knnResult->addElem(elem);
			}
		}
	}

}
