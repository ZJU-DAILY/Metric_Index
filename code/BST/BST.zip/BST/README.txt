Four parameters are needed when starting the program. 
The four parameters are as follows:
dataset filename, cost filename,query filename, the height of the tree
eg.E:\Partition-index\code\dataset\LA.txt BST_LA_cost.txt E:\Partition-index\code\dataset\LA_query.txt 9