#include "Node.h"

Node::Node(vector<Obj> objVec,int h) {

	if (h >= MaxHeight) {
		num = objVec.size();
		bucket = (Obj*)malloc(num*sizeof(Obj));
		for (int i = 0; i < num; i++)
			bucket[i] = objVec[i];
	}
	else {
		bucket = NULL;
		num = -1;
		lChild = NULL;
		rChild = NULL;
		lRadius = 0;
		rRadius = 0;
		full = true;
		if (objVec.size() > 2) {
			double leftId = rand() % objVec.size();
			double *dist = new double[objVec.size()];
			pl = objVec[leftId];
			double maxDist = 0;
			int rightId = -1;
			for (int i = 0; i < objVec.size(); i++) {

				dist[i] = distHelper.distance(objs[pl], objs[objVec[i]]);
				if (dist[i] > maxDist) {
					maxDist = dist[i];
					rightId = i;
				}
			}
			if (rightId == -1) {
				rightId = leftId;
				while (rightId == leftId) rightId = rand() % objVec.size();
			}
			pr = objVec[rightId];
			double tmpDist;
			vector<Obj> lVec, rVec;
			for (int i = 0; i < objVec.size(); i++) {
				if (objVec[i] == pl || objVec[i] == pr) continue;
				tmpDist = distHelper.distance(objs[pr], objs[objVec[i]]);
				if (tmpDist <= dist[i]) {
					rVec.push_back(objVec[i]);
					rRadius = rRadius > tmpDist ? rRadius : tmpDist;
				}
				else {
					lVec.push_back(objVec[i]);
					lRadius = lRadius > dist[i] ? lRadius : dist[i];
				}
			}

			if (lVec.size() != 0) lChild = new Node(lVec, h + 1);
			if (rVec.size() != 0) rChild = new Node(rVec, h + 1);

		}
		else if (objVec.size() == 2) {
			pl = objVec[0];
			pr = objVec[1];
		}
		else if (objVec.size() == 1) {
			pl = objVec[0];
			full = false;
		}
	}


}

void Node::print(){
	cout << "pl:";
    objs[pl].print();
	if (full) {
		cout << "pr:";
		objs[pr].print();
	}
}

Node::~Node() {
	if (bucket != NULL) {
		free(bucket);
		bucket = NULL;
	}
}
