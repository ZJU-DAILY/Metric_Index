Five parameters are needed when starting the program. 
The five parameters are as follows:
dataset filename,index filename, cost filename,query filename, the height of the tree
eg. ../../../dataset/LA.txt LA_index.txt LA_cost.txt ../../../dataset/LA_query.txt 9