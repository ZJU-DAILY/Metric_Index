#pragma once

#include <iostream>
#include <vector>
#include <algorithm>

#include "BPlusTree.h"

using namespace std;

int test_bp_tree(BPNode* node) {
	if (node == NULL) {
		return 0;
	}
	for (int i = 0; i < node->entries.size() - 1; i++)
	{
		if (node->entries[i]->key >= node->entries[i + 1]->key) {
			return 1;
		}
	}
	int sum = 0;
	for (int i = 0; i < node->entries.size(); i++)
	{
		sum += test_bp_tree(node->entries[i]->children);
	}
	return sum;
}

void test_leaf_all(BPTree* bpTree) {
	vector<int> all;
	vector<Entry*> leafs = bpTree->getListLeaf();
	for (int i = 0; i < leafs.size(); i++)
	{
		for (int j = 0; j < leafs[i]->data->obj.size(); j++)
		{
			all.push_back(leafs[i]->data->obj[j]);
		}
	}

	sort(all.begin(), all.end());
	for (int i = 0; i < 200000; i++)
	{
		if (all[i] != i) {
			cout << all[i] << " " << i << endl;
		}
	}
}