#include <stdlib.h>
#include <math.h>
#include <map>
#include <iostream>
#include <algorithm>
#include <iomanip>

#include "BlockTree.h"
#include "object.h"

using namespace std;

#define rand() ((rand()%10000)*10000+rand()%10000)


extern int KS;
extern int capacity;
extern int block_bits;
extern vector<Object*> totalData;

int BlockNode::get_block_value()
{
	int ret = block_value[0];
	for (int i = 0; i < block_bits -1; i++)
	{
		ret = ret * 2 + block_value[i + 1];
	}
	return ret;
}

void BlockNode::blockSearch(BlockNode* node, Object* query, double radius, vector<BlockNode*>& ret) {
	
	if (node->isleaf) {
		ret.push_back(node);
	} else {
		double dist = -1;
		dist = query->distance(*(node->frep));
		double minslice = -1, maxslice = -1;
		minslice = dist - radius;
		maxslice = dist + radius;

		if (minslice < node->dividing_slice_value) {
			BlockNode::blockSearch(node->left, query, radius, ret);
		}

		if (maxslice >= node->dividing_slice_value) {
			BlockNode::blockSearch(node->right, query, radius, ret);
		}
	}
}

bool cmp_pair(pair<double, int> a1, pair<double, int> a2) {
	return a1.first < a2.first; 
}

int select_ref(vector<int> D) {
	int length = D.size();
	int i = 0, ref = 0, temp = 0, position = -1;
	vector<double> dists;
	map<double, int> devs_candidates;
	vector<int> candidates;
	vector<int> devs;

	double dist = 0, max_dist = -1, median = -1, dev = 0;

	temp = D[(rand()) % length];
	candidates.push_back(temp);
	while (i < 10) {
		max_dist = -1;
		dists.clear(); dists.shrink_to_fit();
		for (int i = 0; i < length; i++)
		{
			dist = 0;
			for (int j = 0; j < candidates.size(); j++)
			{
				
				dist += totalData[candidates[j]]->distance(*totalData[D[i]]); 
			}
			if (max_dist < dist) { 
				max_dist = dist;
				position = D[i];
			}
			dists.push_back(dist);
		}
		sort(dists.begin(), dists.end());
		median = dists[length / 2];

		for (int i = 0; i < length; i++)
		{
			dev += fabs(dists[i] - median);
		}
		devs_candidates.insert(make_pair(dev, temp));
		devs.push_back(dev);
		candidates.push_back(temp);
		temp = position;
		++i;
	}

	map<double, int>::reverse_iterator iter = devs_candidates.rbegin();
	int ret = -1;
	if (iter != devs_candidates.rend()) {
		ret = iter->second;
	}

	return ret;
}

void build(BlockNode* node, vector<int> D, vector<double> distances, double R, vector<Entry*>& entries) {
	
	double dist = 0;
	if (D.size() < capacity || node->level == block_bits - 1) {
		double svq = -1, key = -1, minslice = DBL_MAX, maxslice = DBL_MIN, temp = -1;

		node->isleaf = true;
		if (D.size() == 0) {
			return;
		}
		
		node->minslice = floor((pow(2, KS) - 1) * (distances[0] + R) / (2 * R));
		node->maxslice = floor((pow(2, KS) - 1) * (distances[distances.size() - 1] + R) / (2 * R));
		
		for (int i = 0; i < distances.size(); i++)
		{
			svq = floor((pow(2, KS) - 1) * (distances[i] + R) / (2 * R));
			Data* data = new Data(D[i], distances[i]);
			Entry* entry = new Entry(node->get_block_value(), svq, data);
			entries.push_back(entry);
		}
	}
	else {
		int frep;
		frep = select_ref(D);
		vector<pair<double, int>> dist_obj;
		vector<int> DLeft, DRight;
		vector<double> DistLeft, DistRight;

		for (int i = 0; i < D.size(); i++)
		{
			dist_obj.push_back(make_pair(totalData[frep]->distance(*totalData[D[i]]), D[i]));
		}

		sort(dist_obj.begin(), dist_obj.end(), cmp_pair);

		for (int i = 0; i < dist_obj.size(); i++){
			if (dist_obj[i].first < dist_obj[dist_obj.size() / 2].first) {
				DistLeft.push_back(dist_obj[i].first);
				DLeft.push_back(dist_obj[i].second);
			}
			else {
				DistRight.push_back(dist_obj[i].first);
				DRight.push_back(dist_obj[i].second);
			}
		}
		// init block node
		node->frep = totalData[frep];
		node->dividing_slice_value = dist_obj[dist_obj.size() / 2].first;
		node->left = new BlockNode(block_bits);
		node->right = new BlockNode(block_bits);

		node->left->parent_frep = totalData[frep];
		node->right->parent_frep = totalData[frep];

		node->left->level = node->level + 1;
		node->right->level = node->level + 1;
		
		for (int i = 0; i < block_bits; i++)
		{
			node->right->block_value[i] = node->block_value[i];
			node->left->block_value[i] = node->block_value[i];
		}

		node->right->block_value[node->right->level] = 1;

		R = dist_obj[dist_obj.size() - 1].first;

		build(node->left, DLeft, DistLeft, R, entries);
		build(node->right,DRight, DistRight, R, entries);
	}
}


