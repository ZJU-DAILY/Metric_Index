#include <algorithm>
#include <set>
#include <map>
#include <queue>

#include "index.h"

using namespace std;

extern int KS, KEYSIZE;

bool cmp_block_nodes(BlockNode* a1, BlockNode* a2) {
	if (a1->get_block_value() < a2->get_block_value()) {
		return true;
	}
	else if (a1->get_block_value() == a2->get_block_value()) {
		if (a1->minslice < a2->minslice) {
			return true;
		}
		else {
			return false;
		}
	}
	else {
		return false;
	}
}

void get_key(int block_value, int svq, unsigned char* result) {
	int pos = 0, length = KEYSIZE;
	int* key = new int[block_bits + KS];

	for (int i = block_bits; i >= 1; i--) {
		if (block_value & (1 << (i - 1)))
			key[block_bits - i] = 1;
		else
			key[block_bits - i] = 0;
	}
	for (int i = KS; i >= 1; i--) {
		if (svq & (1 << (i - 1)))
			key[block_bits + KS - i] = 1;
		else
			key[block_bits + KS - i] = 0;
	}
	
	memset(result, 0, sizeof(result));
	for (int i = length - 1, pos = block_bits + KS - 1; i >= 0; i--)
	{
		unsigned char ch;
		memset(&ch, 0, sizeof(unsigned char));
		for (int j = 7; j >= 0; j--)
		{
			if (key[pos]) {
				ch |= (1 << (7 - j));
			}
			else {
				ch &= ~(1 << (7 - j));
			}
			pos -= 1;
			if (pos < 0) {
				break;
			}
		}
		result[i] = ch;
		if (pos < 0) {
			break;
		}
	}
	delete key;
}

int search_on_Btree(PB_Tree* pb, B_Node* node, BlockNode* blockNode, vector<pair<double, int>>& v, Object* query, double radius) {
	int flag = -1;
	if (node->level == 0)
	{
		B_Node* p = node;

		unsigned char* key = new unsigned char[node->my_tree->keysize], *next_key = new unsigned char[node->my_tree->keysize];
		get_key(blockNode->get_block_value(), blockNode->minslice, key);
		get_key(blockNode->get_block_value(), blockNode->maxslice, next_key);
		double dis_rep_q, dist;
		dis_rep_q = blockNode->parent_frep->distance(*query);
		
		B_Node* n = p->get_left_sibling();
		vector<B_Node*> leafs;
		while (n) {
			if (n->compareint(key, n->entries[n->num_entries - 1]->key, n->my_tree->keysize) <= 0) {
				leafs.push_back(n);
			}
			else {
				delete n;
				break;
			}
			n = n->get_left_sibling();
		}
		for (int j = 0; j < leafs.size(); j++)
		{
			for (int i = 0; i < leafs[j]->num_entries; i++)
			{
				if (leafs[j]->compareint(key, leafs[j]->entries[i]->key, leafs[j]->my_tree->keysize) <= 0 && 
					leafs[j]->compareint(next_key, leafs[j]->entries[i]->key, leafs[j]->my_tree->keysize) >= 0) {
					if (fabs(dis_rep_q - leafs[j]->entries[i]->dist) - 0.0000001 <= radius) {
						Object* obj = pb->getobject(leafs[j]->entries[i]->ptr);
						dist = query->distance(*obj);
						delete obj;
						if (dist <= radius) {
							v.push_back(make_pair(dist, leafs[j]->entries[i]->son));
						}
					}
				}
			}
			delete leafs[j];
		}
		if (p->compareint(key, p->entries[p->num_entries - 1]->key, p->my_tree->keysize) > 0) {
			p = p->get_right_sibling();
		}
		while (p) {
			for (int i = 0; i < p->num_entries; i++)
			{	
				if (p->compareint(key, p->entries[i]->key, p->my_tree->keysize) <= 0) {
					if (p->compareint(next_key, p->entries[i]->key, p->my_tree->keysize) < 0) {
						B_Node* n = p;
						if (n != node) {
							delete n;
							n = NULL;
						}
						p = NULL;
						break;
					}
					else {
						if (fabs(dis_rep_q - p->entries[i]->dist) - 0.0000001 <= radius) {
							Object* obj = pb->getobject(p->entries[i]->ptr);
							dist = query->distance(*obj);
							delete obj;
							if (dist <= radius) {
								v.push_back(make_pair(dist, p->entries[i]->son));
							}
						}
					}
				}
			}
			if (p) {
				B_Node* n = p;
				p = p->get_right_sibling();
				if (n != node) {
					delete n;
					n = NULL;
				}
			}
		}
		delete[] key;
		delete[] next_key;

		return v.size() > 0;
	}
	unsigned char* key = new unsigned char[node->my_tree->keysize];
	get_key(blockNode->get_block_value(), blockNode->minslice, key);
	int follow = node->max_lesseq_key_pos(key);

	delete[] key;

	if (follow != -1)
	{
		B_Node* succ = node->entries[follow]->get_son();
		flag = search_on_Btree(pb, succ, blockNode, v, query, radius);
		node->entries[follow]->del_son();
	}
	else
		flag = 0;
	return flag;
}

vector<pair<double, int>> rangesearch(PB_Tree* pb, BlockNode* bnode, Object* query, double radius) {

	vector<BlockNode*> blockNodes;
	vector<pair<double, int>> result;

	bnode->blockSearch(bnode, query, radius, blockNodes);
	
	for (int i = 0; i < blockNodes.size(); i++)
	{
		search_on_Btree(pb, pb->bplus->root_ptr, blockNodes[i], result, query, radius);
		
	}
	return result;
}

int get_knn_candidates(PB_Tree* pb, B_Node* node, vector<BlockNode*> blockNodes, double* R, Object* query, int k) {
	int flag = -1;
	if (node->level == 0)
	{
		double dist = -1, min_dist = DBL_MAX, max_radius = -1;
		int pos = -1, count = 0, i = 0, j = 0;
		B_Node* p = node, *left = node, *right = node;
		for (int i = 0; i < node->num_entries; i++)
		{
			Object* obj = pb->getobject(node->entries[i]->ptr);
			dist = query->distance(*obj);
			if (dist < min_dist) {
				min_dist = dist;
				pos = i;
			}
			delete obj;
		}
		max_radius = min_dist;
		count += 1;
		i = pos - 1;
		j = pos + 1;
		while (count != k) {
			if (i >= 0) {
				Object* obj = pb->getobject(left->entries[i]->ptr);
				dist = query->distance(*obj);
				max_radius = max(max_radius, dist);
				++count;
				--i;
				delete obj;
			}
			else {
				if (left->left_sibling != -1) {
					B_Node* p = left;
					left = left->get_left_sibling();
					if (p != node) {
						delete p;
					}
					p = NULL;
					i = left->num_entries - 1;
				}
			}
			if (count == k) {
				break;
			}

			if (j < right->num_entries) {
				Object* obj = pb->getobject(right->entries[j]->ptr);
				dist = query->distance(*obj);
				max_radius = max(max_radius, dist);
				++count;
				++j;
				delete obj;
			} else {
				if (right->right_sibling != -1) {
					B_Node* p = right;
					right = right->get_right_sibling();
					if (p != node) {
						delete p;
					}
					p = NULL;
					j = 0;
				}
			}
			if (count == k) {
				break;
			}
		}
		*R = max_radius;
		return max_radius != -1;
	}
	
	unsigned char* key = new unsigned char[node->my_tree->keysize];
	get_key(blockNodes[0]->get_block_value(), blockNodes[0]->minslice, key);
	int follow = node->max_lesseq_key_pos(key);

	delete[] key;

	if (follow != -1)
	{
		B_Node* succ = node->entries[follow]->get_son();
		flag = get_knn_candidates(pb, succ, blockNodes, R, query, k);
		node->entries[follow]->del_son();
	}
	else
		flag = 0;
	return flag;
}

vector<pair<double, int>> knnsearch(PB_Tree* pb, BlockNode* bnode, Object* query, int k) {
	int flag = -1;
	double R = -1, dist = -1;
	struct paircmp
	{
		bool operator() (pair<double, int> a, pair<double, int> b)
		{
			if (a.first > b.first) {
				return true;
			}
			else if (a.first == b.first) {
				return a.second > b.second;
			}
			else {
				return false;
			}
		}
	};
	vector<pair<double, int>> ret;
	vector<BlockNode*> blockNodes;
	priority_queue<pair<double, int>, vector<pair<double, int>>, paircmp> dist_obj;
	bnode->blockSearch(bnode, query, 0, blockNodes);
	flag = get_knn_candidates(pb, pb->bplus->root_ptr, blockNodes, &R, query, k);
	
	if (flag) {
		vector<pair<double, int>> candidates = rangesearch(pb, bnode, query, R);
		for (int i = 0; i < candidates.size(); i++)
		{
			dist_obj.push(candidates[i]);
		}
		while (!dist_obj.empty() && ret.size() < k) {
			ret.push_back(dist_obj.top());
			dist_obj.pop();
		}
	}
	return ret;
}