#pragma once
#include <vector>

#include "object.h"

using namespace std;

extern int block_bits;

class BlockNode;

class Data {
public:
	int obj;
	double dist;
	
	Data() {
			
	}
	Data(int o, double distance) {
		obj = o;
		dist = distance;
		
	}
};
class Entry {
public:
	Data * data;
	int block_key;
	int svq;

	Entry() {
		data = NULL;
		block_key = -1;
		svq = -1;
	}
	Entry(int x, int y) {
		data = new Data();
		block_key = x;
		svq = y;
	}
	Entry(int x, int y, Data * datum) {
		block_key = x;
		svq = y;
		data = datum;
	}
	Entry * copyWithoutData() {
		Entry * ret = new Entry();
		ret->block_key = block_key;
		ret->svq = svq;
		return ret;
	}
};

class BlockNode {
public:
	vector<int> block_value;
	BlockNode* left = NULL;
	BlockNode* right = NULL;
	double dividing_slice_value = -1;

	Object* frep, * parent_frep;
	int level = 0;

	bool isleaf = false;
	double minslice = -1;
	double maxslice = -1;

	int get_block_value();

	BlockNode(int blockbits) {
		frep = NULL;
		parent_frep = NULL;
		block_value.resize(blockbits);
	}

	BlockNode() {
		frep = NULL;
		parent_frep = NULL;
		block_value.resize(8);
	}

	void blockSearch(BlockNode* block, Object* query, double radius, vector<BlockNode*>& ret);
};

class BlockTree {
public:
	BlockNode* root;
	int blockbits;
	int KS;
	int capacity;

	BlockTree(int bbits, int c, int ks) {
		blockbits = bbits;
		root = new BlockNode(bbits);
		capacity = c;
		KS = ks;
	}
};

int select_ref(std::vector<int> D);

void build(BlockNode* node, vector<int> D, vector<double> distances, double R, vector<Entry*>& entries);
