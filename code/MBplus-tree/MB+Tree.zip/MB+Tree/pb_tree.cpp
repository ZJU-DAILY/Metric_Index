#include "pb-tree.h"
#include ".\gadget\gadget.h"
#include <math.h>
#include <vector>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <sstream>
#include <bitset>
#include <queue>

#include "BlockTree.h"

using namespace std;

extern double cc;
extern double IOread;
extern int EPS, MAXINT, BITS, KS, KEYSIZE;

PB_Tree::PB_Tree()
{
	bplus = NULL;
	draf = NULL;
	c = NULL;
}

PB_Tree::~PB_Tree()
{
	if (bplus != NULL)
		delete bplus;
	if (draf != NULL)
		delete draf;
}

bool cmp_entry(Entry* a1, Entry* a2) {
	if (a1->block_key < a2->block_key) {
		return true;
	}
	else if (a1->block_key == a2->block_key) {
		if (a1->svq < a2->svq) {
			return true;
		}
		else {
			return false;
		}
	}
	else {
		return false;
	}
}

void get_key_By_char(int block_value, int svq, unsigned char* result) {
	int pos = 0, length = KEYSIZE;
	int* key = new int[block_bits + KS];

	for (int i = block_bits; i >= 1; i--) {
		if (block_value & (1 << (i - 1)))
			key[block_bits - i] = 1;
		else
			key[block_bits - i] = 0;
	}
	for (int i = KS; i >= 1; i--) {
		if (svq & (1 << (i - 1)))
			key[block_bits + KS - i] = 1;
		else
			key[block_bits + KS - i] = 0;
	}

	memset(result, 0, sizeof(result));
	for (int i = length - 1, pos = block_bits + KS - 1; i >= 0; i--)
	{
		unsigned char ch;
		memset(&ch, 0, sizeof(unsigned char));
		for (int j = 7; j >= 0; j--)
		{
			if (key[pos]) {
				ch |= (1 << (7 - j));
			}
			else {
				ch &= ~(1 << (7 - j));
			}
			pos -= 1;
			if (pos < 0) {
				break;
			}
		}
		result[i] = ch;
		if (pos < 0) {
			break;
		}
	}
	delete key;
}

void PB_Tree::H_bulkload(vector<Entry*> entries)
{
	sort(entries.begin(), entries.end(), cmp_entry);
	
	FILE* f = fopen("bulkload.txt", "w");
	unsigned char* key = new unsigned char[KEYSIZE];
	if (f != NULL)
	{
		for (int i = 0; i < entries.size(); i++)
		{
			fprintf(f, "%d", entries[i]->data->obj);
			get_key_By_char(entries[i]->block_key, entries[i]->svq, key);
			for (int j = 0; j < KEYSIZE; j++)
			{
				fprintf(f, " %d", key[j]);
			}
			fprintf(f, " %.10lf", entries[i]->data->dist);
			fprintf(f, "\n");
		}
		fclose(f);
	}
	delete key;
}


Object* PB_Tree::getobject(int ptr)
{
	int i = ptr / draf->file->blocklength;
	char * buffer = new char[draf->file->blocklength];

	if (c == NULL)
	{
		draf->file->read_block(buffer, i);
	}
	else
	{
		c->read_block(buffer, i, draf);
	}

	int j = ptr - i * draf->file->blocklength;
	Object* o = new Object();
	o->read_from_buffer(&buffer[j]);

	delete[] buffer;

	return o;
}
