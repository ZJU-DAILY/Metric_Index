
#ifndef __PBTREE
#define __PBTREE

#include ".\btree\b-tree.h"
#include ".\object.h"
#include ".\RAF.h"
#include ".\blockfile\cache.h"
#include ".\blockfile\blk_file.h"
#include ".\btree\b-node.h"
#include ".\btree\b-entry.h"

#include "BlockTree.h"

#define WORDBITS 32
#define NUMBITS 32

class kNNEntry
{
public:
	int ptr;
	int edist;
	int level;
	kNNEntry()
	{
	}

	kNNEntry(const kNNEntry &a)
	{
		ptr = a.ptr;
		edist = a.edist;
		level = a.level;
	}
	bool operator < (const kNNEntry &a) const 
	{
		if(fabs((double) edist-a.edist)<0.0001)
			return level >a.level;
		return (edist>a.edist); 
	}
};

class PB_Tree
{
public:
	B_Tree * bplus;
	RAF * draf;
	Cache* c;

	int bits; 
	

	PB_Tree();
	~PB_Tree();

    void bulkload(Object* O,int o_num);
	void H_bulkload(vector<Entry*> entries);
	Object * getobject (int ptr);
   
};
#endif