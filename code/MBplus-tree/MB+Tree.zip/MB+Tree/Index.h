#pragma once
#include <vector>
#include <iostream>

#include "pb-tree.h"

using namespace std;

vector<pair<double, int>> rangesearch(PB_Tree* pb, BlockNode* bnode, Object* query, double radius);
vector<pair<double, int>> knnsearch(PB_Tree* pb, BlockNode* bnode, Object* query, int k);