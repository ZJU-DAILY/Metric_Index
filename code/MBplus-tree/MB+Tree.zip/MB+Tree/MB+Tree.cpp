﻿#include <iostream>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <string>
#include <algorithm>
#include <cstring>
#include <fstream>
#include <stdlib.h>

#include <string>

using namespace std;

#include "./blockfile/f_def.h"
#include "./blockfile/blk_file.h"
#include "./blockfile/cache.h"
#include "./gadget/gadget.h"
#include "./heap/binheap.h"
#include "./heap/heap.h"
#include "./rand/rand.h"
#include "./object.h"
#include "./pb-tree.h"

#include "index.h"
#include "BlockTree.h"
#include <iomanip>

// source data parameters
int num_obj = 0;
int dim = 0;
int func = 2;
int qcounts;
vector<Object*> totalData;

// B+ Tree
int bolcksize = 0;
int blockLength = 0;

// Block parameters
int KS = -1;
int capacity = -1;
int block_bits = 0;
int KEYSIZE = 0;

// performance parameters
double compdists = 0;
double IOread;
double IOwrite;

ofstream performance;

Object** readobjects(char* filename, int num_obj, int dim)
{
	FILE* fp;

	int record_count = 0; 
	Object** objset = new Object * [num_obj];
	for (int i = 0; i < num_obj; i++)
	{
		objset[i] = new Object();
	}

	if ((fp = fopen(filename, "r")) == NULL)
	{
		for (int i = 0; i < num_obj; i++)
		error("Could not open the data file",TRUE);
	}
	else
	{
		fscanf(fp, "%d %d %d", &dim, &num_obj, &func); 
		cout << dim << " " << num_obj << " " << func << endl;
		while (record_count < num_obj)
		{
			float d;
			objset[record_count]->id = record_count;
			objset[record_count]->size = dim;
			try {
				objset[record_count]->data = new float[objset[record_count]->size];
			}
			catch (exception e) {
				cout << e.what() << endl;
				objset[record_count]->data = new float[objset[record_count]->size];
			}
			
			for (int i = 0; i < objset[record_count]->size; i++)
			{
				fscanf(fp, "%f", &d);
				objset[record_count]->data[i] = d;
			}
			fscanf(fp, "\n");
			record_count++;
		}
	}

	return objset;
}

Object* readobjects2(char* filename)
{
	FILE* fp;
	int record_count = 0;

	if ((fp = fopen(filename, "r")) == NULL)
	{
		error("Could not open the data file", TRUE);
		return NULL;
	}
	else
	{
		fscanf(fp, "%d %d %d", &dim, &num_obj, &func); 
		cout << dim << " " << num_obj << " " << func << endl;
		Object* objset = new Object[num_obj];
		while (record_count < num_obj)
		{
			float d;
			
			objset[record_count].id = record_count; // the id of object
			objset[record_count].size = dim;        // the length of obejct
			objset[record_count].data = new float[dim];  // the entry if object
			for (int i = 0; i < dim; i++)
			{
				fscanf(fp, "%f", &d); 
				objset[record_count].data[i] = d;
			}
			fscanf(fp, "\n");
			record_count++;
		}
		return objset;
	}

}

BlockNode* bulidIndex(char* index_name, char* filename)
{
	PB_Tree* pb = new PB_Tree();
	KEYSIZE = ceil((double)(block_bits + KS) / 8.0);

	Object* os = readobjects2(filename);
	
	vector<double> distances;
	vector<Entry*> entries;
	vector<int> objIdset;

	for (int i = 0; i < num_obj; i++)
	{
		totalData.push_back(&os[i]);
	}
	
	BlockNode* bnode = new BlockNode(block_bits);
	
	objIdset.resize(num_obj);
	generate(objIdset.begin(), objIdset.end(), [n = 0]()mutable{return n++; });

	build(bnode, objIdset, distances, KS, entries);
	
	pb->H_bulkload(entries);

	pb->bplus = new B_Tree();
	pb->bplus->init(index_name, blockLength, NULL, KEYSIZE);
	pb->bplus->bulkload("bulkload.txt");

	pb->bplus->load_root();
	B_Node* node = pb->bplus->root_ptr;
	B_Node* temp;

	while (node->level != 0)
	{
		node = node->entries[0]->get_son();
	}
	int* obj_order = new int[num_obj];
	int k = 0;
	for (int i = 0; i < node->num_entries; i++)
	{
		obj_order[k] = node->entries[i]->son;
		k++;
	}
	temp = node->get_right_sibling();

	while (temp != NULL)
	{
		
		node = temp;
		for (int i = 0; i < node->num_entries; i++)
		{
			obj_order[k] = node->entries[i]->son;
			k++;
		}
		temp = node->get_right_sibling();
		delete node;
	}

	pb->draf = new RAF();
	pb->draf->num_obj = num_obj;
	pb->draf->init(index_name, blockLength, NULL);

	Object** objS = readobjects(filename, num_obj, dim);
	int* result = pb->draf->buid_from_array(objS, obj_order);

	for (int i = 0; i < num_obj; i++)
		delete objS[i];
	delete[] obj_order;

	node = pb->bplus->root_ptr;


	while (node->level != 0)
	{
		node = node->entries[0]->get_son();
	}

	k = 0;
	for (int i = 0; i < node->num_entries; i++)
	{
		node->entries[i]->ptr = result[k];
		k++;
	}
	char* buffer = new char[blockLength];
	node->write_to_buffer(buffer);

	pb->bplus->file->write_block(buffer, node->block);
	delete buffer;

	temp = node->get_right_sibling();

	while (temp != NULL)
	{
		buffer = new char[blockLength];
		node = temp;
		for (int i = 0; i < node->num_entries; i++)
		{
			node->entries[i]->ptr = result[k];
			k++;
		}
		node->write_to_buffer(buffer);

		pb->bplus->file->write_block(buffer, node->block);

		delete buffer;
		temp = node->get_right_sibling();
		delete node;
	}
	delete[] result;

	pb->bplus->close();
	return bnode;
}

int main(int argc, char** argv)
{
	char* datafile = argv[1];
	char* indexfile = argv[2];
	char* costfile = argv[3];
	char* querydata = argv[5];
	int MAXDIST = atoi(argv[6]);
	
	// cache
	int buffer_size = 128;

	blockLength = bolcksize = atoi(argv[4]);
	KS = ceil(log(MAXDIST) / log(2));

	capacity = 100;
	block_bits = 8;

	int KNN[6];
	double radius[7];
	qcounts = 100;
	
	performance.open(costfile, ios::out);

	int knn[6] = { 1, 5, 10, 20, 50, 100 };
	memcpy(KNN, knn, sizeof(knn));
	double r[] = { 2321, 2733, 3229, 3843, 4614, 5613, 7090 };
	memcpy(radius, r, sizeof(r));

	if (string(datafile).find("LA") != -1) {
		double r[] = { 473, 692, 989, 1409, 1875, 2314, 3096 };
		memcpy(radius, r, sizeof(r));
	}
	else if (string(datafile).find("integer") != -1) {
		double r[] = { 2321,2733, 3229,3843, 4614, 5613, 7090 };
		memcpy(radius, r, sizeof(r));
	}
	else if (string(datafile).find("sf") != -1) {
		double r[] = { 100, 200, 300, 400, 500, 600, 700 };
		memcpy(radius, r, sizeof(r));
	}
	else if (string(datafile).find("mpeg_1M") != -1) {
		double r[] = { 3838, 4092, 4399, 4773, 5241, 5904, 7104 };
		memcpy(radius, r, sizeof(r));
	}

	clock_t begin, end;
	struct stat sdata1;
	struct stat sdata2;
	IOread = IOwrite = compdists = 0;
	begin = clock();
	BlockNode* bnode = bulidIndex(indexfile, datafile);
	end = clock();

	performance << "building..." << endl;
	performance << "finished... " << (double)(end - begin) / CLOCKS_PER_SEC << " build time" << endl;
	performance << "finished... " << compdists <<" distances computed" << endl;
	performance << "finished... " << IOread + IOwrite <<" IO times" << endl;

	string bfile = indexfile, raffile = indexfile;
	bfile += ".b"; raffile += ".raf";
	stat(bfile.c_str(), &sdata1);
	stat(raffile.c_str(), &sdata2);
	performance << "saved... " << (long long)(sdata1.st_size + sdata2.st_size) << " bytes" << endl;
	
	performance << endl << "querying..." << endl;
	
	
	PB_Tree* pb = new PB_Tree();
	Cache* c = new Cache(buffer_size, bolcksize);
	pb->c = c;
	pb->bplus = new B_Tree();
	pb->bplus->init_restore(indexfile, c);
	pb->bplus->load_root();
	pb->draf = new RAF();
	pb->draf->init_restore(indexfile, c);
	
	double dists = 0;
	double rad = 0;
	cout << "KNN Query" << endl;
	for (int i = 0; i < 6; i++)
	{
		cout << "knn: " << knn[i] << endl;
		ifstream in(querydata, ios::in);
		Object* obj = new Object();
		obj->size = dim;
		obj->data = new float[dim];
		obj->id = num_obj;

		dists = 0;
		rad = 0;
		begin = clock();
		IOread = IOwrite = 0;

		for (int j = 0; j < qcounts; j++)
		{
			for (int m = 0; m < dim; m++) {
				in >> obj->data[m];
			}
			obj->id = j;

			compdists = 0;

			vector<pair<double, int>> ret = knnsearch(pb, bnode, obj, knn[i]);
			if (ret.size() != 0) {
				rad += ret.back().first;
			}
			else {
				cout << "knn query failed: " << j << " " << knn[i] << endl;
			}
			dists += compdists;
		}

		end = clock();
		performance << "k: " << knn[i] << endl;
		performance << "finished..." << (double)(end - begin) / CLOCKS_PER_SEC / qcounts << fixed << setprecision(6) << " query time" << endl;
		performance << "finished..." << dists / qcounts << fixed << setprecision(6) << " distances computed" << endl;
		performance << "finished..." << IOread / qcounts << fixed << setprecision(6) << " IO times" << endl;
		performance << "finished..." << rad / qcounts << fixed << setprecision(6) << " radius" << endl;

		delete obj;
		in.close();
	}

	cout << "Range Query" << endl;
	for (int i = 0; i < 7; i++)
	{
		cout << "range: " << radius[i] << endl;
		ifstream in(querydata, ios::in);
		Object* obj = new Object();
		obj->size = dim;
		obj->data = new float[dim];
		obj->id = num_obj;
		
		dists = 0;
		rad = 0;
		begin = clock();
		IOread = IOwrite = 0;

		for (int j = 0; j < qcounts; j++)
		{
			compdists = 0;

			for (int m = 0; m < dim; m++) {
				in >> obj->data[m];
			}
			vector<pair<double, int>> ret = rangesearch(pb, bnode, obj, radius[i]);
			if (ret.size() != 0) {
				rad += ret.size();
			}
			else {
				cout << "range query failed: " << j << " " << radius[i] << endl;
			}
			dists += compdists;
		}
		end = clock();
		performance << "r: " << radius[i] << endl;
		performance << "finished..." << (double)(end-begin) / CLOCKS_PER_SEC / qcounts << fixed << setprecision(6) << " query time" << endl;
		performance << "finished..." << dists / qcounts << fixed << setprecision(6) << " distances computed" << endl;
		performance << "finished..." << IOread / qcounts << fixed << setprecision(6) << " IO times" << endl;
		performance << "finished..." << rad / qcounts << fixed << setprecision(6)<<" objs" << endl;
		delete obj;
		in.close();
	}

	performance.close();
	return 0;
}
