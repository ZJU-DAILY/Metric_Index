/* this file contains necessary definitions for B-tree */

#ifndef __BDEF
#define __BDEF

#include <stdlib.h>
#include <stdio.h>
//-----------------------------------------------

#define B_MAXINT 99999999

//-----------------------------------------------

enum BINSRT {B_NRML, B_OVRFLW};
enum BDEL {B_NONE, B_UNDRFLW, B_NOTFOUND};

//-----------------------------------------------

#endif
